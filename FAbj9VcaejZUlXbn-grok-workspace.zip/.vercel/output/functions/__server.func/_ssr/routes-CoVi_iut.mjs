import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Play, c as Lock, i as RotateCcw, l as Flag, n as Volume2, o as Pause, s as Map, t as VolumeX } from "../_libs/lucide-react.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CoVi_iut.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var buttonVariants = cva("inline-flex min-h-11 items-center justify-center gap-2 rounded-md px-4 text-sm font-medium transition-[transform,background-color,color,opacity] duration-150 ease-[cubic-bezier(0.22,1,0.36,1)] select-none focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent disabled:pointer-events-none disabled:opacity-40 active:scale-[0.98]", {
	variants: {
		variant: {
			primary: "bg-accent text-accent-fg hover:bg-fg",
			secondary: "border border-border bg-surface-2 text-fg hover:border-border-strong hover:bg-surface",
			ghost: "text-muted hover:bg-surface-2 hover:text-fg",
			danger: "bg-danger text-fg hover:opacity-90"
		},
		size: {
			default: "min-h-11 px-4",
			lg: "min-h-12 px-5 text-base",
			icon: "size-11 px-0"
		}
	},
	defaultVariants: {
		variant: "primary",
		size: "default"
	}
});
var Button = (0, import_react.forwardRef)(({ className, variant, size, type = "button", ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
	ref,
	type,
	className: cn(buttonVariants({
		variant,
		size
	}), className),
	...props
}));
Button.displayName = "Button";
var AudioBus = class {
	ctx = null;
	master = null;
	muted = false;
	unlock() {
		if (!this.ctx) {
			const Ctor = window.AudioContext || window.webkitAudioContext;
			this.ctx = new Ctor({ latencyHint: "interactive" });
			this.master = this.ctx.createGain();
			this.master.gain.value = this.muted ? 0 : .7;
			this.master.connect(this.ctx.destination);
		}
		if (this.ctx.state === "suspended") this.ctx.resume();
	}
	resume() {
		if (this.ctx?.state === "suspended") this.ctx.resume();
	}
	setMuted(muted) {
		this.muted = muted;
		if (this.master && this.ctx) this.master.gain.setTargetAtTime(muted ? 0 : .7, this.ctx.currentTime, .02);
	}
	tone(freq, dur, type, gain = .12, slide = 0) {
		if (!this.ctx || !this.master || this.muted) return;
		const t = this.ctx.currentTime;
		const osc = this.ctx.createOscillator();
		const g = this.ctx.createGain();
		osc.type = type;
		osc.frequency.setValueAtTime(freq, t);
		if (slide) osc.frequency.exponentialRampToValueAtTime(Math.max(40, freq + slide), t + dur);
		g.gain.setValueAtTime(1e-4, t);
		g.gain.exponentialRampToValueAtTime(gain, t + .012);
		g.gain.exponentialRampToValueAtTime(1e-4, t + dur);
		osc.connect(g);
		g.connect(this.master);
		osc.start(t);
		osc.stop(t + dur + .02);
		osc.onended = () => {
			osc.disconnect();
			g.disconnect();
		};
	}
	eat() {
		const jitter = 1 + (Math.random() * .16 - .08);
		this.tone(620 * jitter, .07, "sine", .1);
		this.tone(930 * jitter, .05, "triangle", .05);
	}
	burst() {
		this.tone(180, .28, "sawtooth", .1, -120);
		this.tone(70, .34, "square", .06, -30);
	}
	unlockFlag() {
		this.tone(440, .12, "sine", .09);
		this.tone(660, .16, "triangle", .07);
	}
	win() {
		this.tone(523, .14, "sine", .1);
		this.tone(659, .16, "sine", .09);
		this.tone(784, .22, "triangle", .08);
	}
	click() {
		this.tone(480, .04, "square", .04);
	}
};
var GAME_CODES = /* @__PURE__ */ new Set([
	"KeyW",
	"KeyA",
	"KeyS",
	"KeyD",
	"ArrowUp",
	"ArrowDown",
	"ArrowLeft",
	"ArrowRight",
	"Space",
	"KeyP",
	"Escape",
	"Enter",
	"KeyM"
]);
function radialDeadzone(x, y, dz = .18) {
	const m = Math.hypot(x, y);
	if (m < dz) return {
		x: 0,
		y: 0
	};
	const scale = (m - dz) / (1 - dz) / m;
	return {
		x: x * scale,
		y: y * scale
	};
}
var Input = class {
	keys = /* @__PURE__ */ new Set();
	injected = null;
	touchSteer = 0;
	touchBoost = false;
	touchBrake = false;
	injectedSteer = null;
	prevPause = false;
	prevConfirm = false;
	pausePressed = false;
	confirmPressed = false;
	attach() {
		window.addEventListener("keydown", this.onKeyDown);
		window.addEventListener("keyup", this.onKeyUp);
		window.addEventListener("blur", this.onBlur);
		document.addEventListener("visibilitychange", this.onBlur);
	}
	detach() {
		window.removeEventListener("keydown", this.onKeyDown);
		window.removeEventListener("keyup", this.onKeyUp);
		window.removeEventListener("blur", this.onBlur);
		document.removeEventListener("visibilitychange", this.onBlur);
		this.keys.clear();
	}
	setKeys(codes) {
		this.injected = codes.length ? [...codes] : null;
	}
	onKeyDown = (e) => {
		if (GAME_CODES.has(e.code)) e.preventDefault();
		this.keys.add(e.code);
	};
	onKeyUp = (e) => {
		this.keys.delete(e.code);
	};
	onBlur = () => {
		this.keys.clear();
		this.touchSteer = 0;
		this.touchBoost = false;
		this.touchBrake = false;
	};
	sample() {
		const held = this.injected ? new Set(this.injected) : this.keys;
		let steer = this.injectedSteer ?? this.touchSteer;
		if (this.injectedSteer == null) {
			if (held.has("KeyA") || held.has("ArrowLeft")) steer += 1;
			if (held.has("KeyD") || held.has("ArrowRight")) steer -= 1;
		}
		const pads = typeof navigator !== "undefined" ? navigator.getGamepads?.() : null;
		if (pads) for (const pad of pads) {
			if (!pad || pad.mapping !== "standard") continue;
			const stick = radialDeadzone(pad.axes[0] ?? 0, pad.axes[1] ?? 0);
			steer += -stick.x;
			if (pad.buttons[0]?.pressed || (pad.buttons[7]?.value ?? 0) > .4) this.touchBoost = true;
			if (pad.buttons[1]?.pressed || (pad.buttons[6]?.value ?? 0) > .4) this.touchBrake = true;
			if (pad.buttons[12]?.pressed) this.touchBoost = true;
			if (pad.buttons[13]?.pressed) this.touchBrake = true;
			if (pad.buttons[14]?.pressed) steer += 1;
			if (pad.buttons[15]?.pressed) steer -= 1;
		}
		steer = Math.max(-1, Math.min(1, steer));
		const boost = held.has("KeyW") || held.has("ArrowUp") || held.has("Space") || this.touchBoost;
		const brake = held.has("KeyS") || held.has("ArrowDown") || this.touchBrake;
		const pause = held.has("KeyP") || held.has("Escape");
		const confirm = held.has("Enter");
		this.pausePressed = pause && !this.prevPause;
		this.confirmPressed = confirm && !this.prevConfirm;
		this.prevPause = pause;
		this.prevConfirm = confirm;
		return {
			steer,
			boost,
			brake,
			pause,
			confirm
		};
	}
};
var PLAYER_PALETTE = {
	body: "#6fe0b0",
	mid: "#3aa97c",
	tail: "#1d6a4c",
	eye: "#0c100e"
};
var ENEMY_PALETTES = [
	{
		body: "#e07a68",
		mid: "#c45c4a",
		tail: "#7a3328",
		eye: "#1a0c0a"
	},
	{
		body: "#7ea4bc",
		mid: "#5b8299",
		tail: "#2e4a5a",
		eye: "#0c1216"
	},
	{
		body: "#c48aa0",
		mid: "#a06880",
		tail: "#5a3848",
		eye: "#160c10"
	},
	{
		body: "#8aaa6e",
		mid: "#6a8a52",
		tail: "#3a4e2c",
		eye: "#0c140a"
	},
	{
		body: "#c4a070",
		mid: "#a08050",
		tail: "#5a4830",
		eye: "#14100a"
	},
	{
		body: "#6aa8a4",
		mid: "#4a8480",
		tail: "#285250",
		eye: "#0a1212"
	}
];
function grid(cols, rows, paint) {
	const walls = new Uint8Array(cols * rows);
	const set = (x, y, v = 1) => {
		if (x >= 0 && y >= 0 && x < cols && y < rows) walls[y * cols + x] = v;
	};
	for (let x = 0; x < cols; x++) {
		set(x, 0);
		set(x, rows - 1);
	}
	for (let y = 0; y < rows; y++) {
		set(0, y);
		set(cols - 1, y);
	}
	paint?.(set);
	return walls;
}
function enemy(x, y, yaw, length, palette, speed) {
	return {
		x,
		y,
		yaw,
		length,
		palette,
		speed
	};
}
var T = 40;
var LEVELS = [
	{
		id: 1,
		name: "Clearing",
		blurb: "A quiet field. Grow, then take the banner.",
		cols: 28,
		rows: 18,
		tile: T,
		walls: grid(28, 18, (set) => {
			set(8, 5);
			set(9, 5);
			set(8, 6);
			set(9, 6);
			set(19, 11);
			set(20, 11);
			set(19, 12);
			set(20, 12);
		}),
		player: {
			x: 5,
			y: 9,
			yaw: -Math.PI / 2
		},
		enemies: [enemy(22, 4, Math.PI / 2, 70, ENEMY_PALETTES[0], 128), enemy(22, 14, Math.PI / 2, 62, ENEMY_PALETTES[1], 122)],
		foodCount: 12,
		foodToUnlock: 8,
		flag: {
			x: 24,
			y: 9
		},
		turnRate: 4.4,
		baseSpeed: 168,
		boostSpeed: 250,
		brakeSpeed: 92
	},
	{
		id: 2,
		name: "Ruins",
		blurb: "Pillars break the line of sight. Watch the corners.",
		cols: 30,
		rows: 20,
		tile: T,
		walls: grid(30, 20, (set) => {
			for (const [x, y] of [
				[7, 6],
				[8, 6],
				[7, 7],
				[8, 7],
				[15, 4],
				[16, 4],
				[15, 5],
				[16, 5],
				[22, 8],
				[23, 8],
				[22, 9],
				[23, 9],
				[10, 13],
				[11, 13],
				[10, 14],
				[11, 14],
				[18, 15],
				[19, 15],
				[18, 16],
				[19, 16]
			]) set(x, y);
		}),
		player: {
			x: 4,
			y: 10,
			yaw: -Math.PI / 2
		},
		enemies: [
			enemy(25, 4, Math.PI / 2, 78, ENEMY_PALETTES[0], 136),
			enemy(25, 16, Math.PI / 2, 70, ENEMY_PALETTES[2], 130),
			enemy(14, 10, 0, 64, ENEMY_PALETTES[3], 124)
		],
		foodCount: 14,
		foodToUnlock: 10,
		flag: {
			x: 26,
			y: 10
		},
		turnRate: 4.5,
		baseSpeed: 176,
		boostSpeed: 262,
		brakeSpeed: 96
	},
	{
		id: 3,
		name: "Hedge",
		blurb: "Lanes and gaps. Cut through, don't get boxed in.",
		cols: 32,
		rows: 20,
		tile: T,
		walls: grid(32, 20, (set) => {
			for (const y of [
				5,
				10,
				15
			]) for (let x = 2; x < 30; x++) if (x % 10 < 7) set(x, y);
		}),
		player: {
			x: 4,
			y: 2,
			yaw: -Math.PI / 2
		},
		enemies: [
			enemy(28, 3, Math.PI / 2, 86, ENEMY_PALETTES[1], 142),
			enemy(28, 8, Math.PI / 2, 74, ENEMY_PALETTES[0], 138),
			enemy(4, 12, -Math.PI / 2, 70, ENEMY_PALETTES[4], 134),
			enemy(16, 17, Math.PI, 80, ENEMY_PALETTES[2], 140)
		],
		foodCount: 16,
		foodToUnlock: 12,
		flag: {
			x: 28,
			y: 17
		},
		turnRate: 4.6,
		baseSpeed: 182,
		boostSpeed: 272,
		brakeSpeed: 98
	},
	{
		id: 4,
		name: "Split",
		blurb: "Two chambers, narrow doors. The banner waits on the far side.",
		cols: 32,
		rows: 22,
		tile: T,
		walls: grid(32, 22, (set) => {
			for (let y = 1; y < 21; y++) {
				if (y === 6 || y === 15) continue;
				set(16, y);
			}
			for (let x = 6; x <= 10; x++) {
				set(x, 8);
				set(x, 14);
			}
			for (let x = 21; x <= 25; x++) {
				set(x, 8);
				set(x, 14);
			}
		}),
		player: {
			x: 4,
			y: 11,
			yaw: -Math.PI / 2
		},
		enemies: [
			enemy(12, 4, 0, 90, ENEMY_PALETTES[0], 148),
			enemy(12, 18, Math.PI, 82, ENEMY_PALETTES[3], 144),
			enemy(26, 4, Math.PI / 2, 88, ENEMY_PALETTES[1], 150),
			enemy(26, 18, Math.PI / 2, 76, ENEMY_PALETTES[5], 146)
		],
		foodCount: 16,
		foodToUnlock: 12,
		flag: {
			x: 28,
			y: 11
		},
		turnRate: 4.7,
		baseSpeed: 188,
		boostSpeed: 282,
		brakeSpeed: 100
	},
	{
		id: 5,
		name: "Den",
		blurb: "Crowded, fast, unforgiving. Claim the last banner.",
		cols: 34,
		rows: 22,
		tile: T,
		walls: grid(34, 22, (set) => {
			for (let i = 4; i < 30; i += 6) for (let k = 0; k < 3; k++) {
				set(i, 4 + k);
				set(i + 1, 4 + k);
				set(i, 15 + k);
				set(i + 1, 15 + k);
			}
			for (let x = 10; x <= 23; x++) {
				if (x === 16 || x === 17) continue;
				set(x, 11);
			}
		}),
		player: {
			x: 4,
			y: 11,
			yaw: -Math.PI / 2
		},
		enemies: [
			enemy(30, 3, Math.PI / 2, 96, ENEMY_PALETTES[0], 158),
			enemy(30, 11, Math.PI / 2, 88, ENEMY_PALETTES[2], 154),
			enemy(30, 19, Math.PI / 2, 92, ENEMY_PALETTES[1], 156),
			enemy(17, 3, 0, 80, ENEMY_PALETTES[4], 150),
			enemy(17, 19, Math.PI, 84, ENEMY_PALETTES[5], 152)
		],
		foodCount: 18,
		foodToUnlock: 14,
		flag: {
			x: 31,
			y: 11
		},
		turnRate: 4.9,
		baseSpeed: 198,
		boostSpeed: 298,
		brakeSpeed: 108
	}
];
var TOTAL_LEVELS = LEVELS.length;
function getLevel(id) {
	return LEVELS[Math.max(0, Math.min(LEVELS.length - 1, id - 1))];
}
function tileCenter(level, col, row) {
	return {
		x: (col + .5) * level.tile,
		y: (row + .5) * level.tile
	};
}
function isWall(level, col, row) {
	if (col < 0 || row < 0 || col >= level.cols || row >= level.rows) return true;
	return level.walls[row * level.cols + col] === 1;
}
function computeCam(world, viewW, viewH, follow, dt, cam) {
	const { w, h } = world.worldSize();
	const targetScale = Math.min(viewW / 980, viewH / 720);
	cam.scale += (Math.max(.38, Math.min(1.15, targetScale)) - cam.scale) * (1 - Math.exp(-8 * dt));
	const target = follow ?? {
		x: w / 2,
		y: h / 2
	};
	cam.x += (target.x - cam.x) * (1 - Math.exp(-6 * dt));
	cam.y += (target.y - cam.y) * (1 - Math.exp(-6 * dt));
	const shake = world.trauma * world.trauma;
	cam.shakeX = (Math.random() * 2 - 1) * 14 * shake;
	cam.shakeY = (Math.random() * 2 - 1) * 14 * shake;
	cam.shakeR = (Math.random() * 2 - 1) * .03 * shake;
	return cam;
}
function createCam() {
	return {
		x: 0,
		y: 0,
		scale: .7,
		shakeX: 0,
		shakeY: 0,
		shakeR: 0
	};
}
function drawWorld(ctx, world, viewW, viewH, cam, dpr) {
	ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
	ctx.clearRect(0, 0, viewW, viewH);
	ctx.fillStyle = "#0c100e";
	ctx.fillRect(0, 0, viewW, viewH);
	ctx.save();
	ctx.translate(viewW / 2 + cam.shakeX, viewH / 2 + cam.shakeY);
	ctx.rotate(cam.shakeR);
	ctx.scale(cam.scale, cam.scale);
	ctx.translate(-cam.x, -cam.y);
	const { w, h } = world.worldSize();
	drawFloor(ctx, world.level, w, h);
	drawWalls(ctx, world.level);
	drawFlag(ctx, world.flag, world.time, world.eaten, world.level.foodToUnlock);
	for (const f of world.food) drawFood(ctx, f, world.time);
	const snakes = world.snakes.filter((s) => s.alive);
	snakes.sort((a, b) => Number(a.isPlayer) - Number(b.isPlayer));
	for (const s of snakes) drawSnake(ctx, s, world);
	drawFx(ctx, world);
	ctx.restore();
	const g = ctx.createRadialGradient(viewW / 2, viewH / 2, viewW * .2, viewW / 2, viewH / 2, viewW * .75);
	g.addColorStop(0, "rgba(12,16,14,0)");
	g.addColorStop(1, "rgba(12,16,14,0.42)");
	ctx.fillStyle = g;
	ctx.fillRect(0, 0, viewW, viewH);
}
function drawFloor(ctx, level, w, h) {
	ctx.fillStyle = "#121814";
	ctx.fillRect(0, 0, w, h);
	ctx.strokeStyle = "rgba(232,238,233,0.035)";
	ctx.lineWidth = 1;
	const t = level.tile;
	ctx.beginPath();
	for (let x = 0; x <= w; x += t) {
		ctx.moveTo(x, 0);
		ctx.lineTo(x, h);
	}
	for (let y = 0; y <= h; y += t) {
		ctx.moveTo(0, y);
		ctx.lineTo(w, y);
	}
	ctx.stroke();
}
function drawWalls(ctx, level) {
	const t = level.tile;
	for (let r = 0; r < level.rows; r++) for (let c = 0; c < level.cols; c++) {
		if (!isWall(level, c, r)) continue;
		const x = c * t;
		const y = r * t;
		ctx.fillStyle = "#1c2621";
		roundRect(ctx, x + 1, y + 1, t - 2, t - 2, 6);
		ctx.fill();
		ctx.fillStyle = "rgba(232,238,233,0.05)";
		roundRect(ctx, x + 3, y + 2, t - 6, t * .28, 4);
		ctx.fill();
	}
}
function drawFood(ctx, f, time) {
	const pulse = 1 + Math.sin(time * 5.5 + f.seed) * .12;
	const r = f.r * pulse;
	const g = ctx.createRadialGradient(f.x, f.y, 0, f.x, f.y, r * 3);
	g.addColorStop(0, "rgba(232,238,233,0.28)");
	g.addColorStop(1, "rgba(232,238,233,0)");
	ctx.fillStyle = g;
	ctx.beginPath();
	ctx.arc(f.x, f.y, r * 3, 0, Math.PI * 2);
	ctx.fill();
	ctx.fillStyle = f.value > 1 ? "#d5dbd6" : "#b8c4ba";
	ctx.beginPath();
	ctx.arc(f.x, f.y, r, 0, Math.PI * 2);
	ctx.fill();
	ctx.fillStyle = "rgba(255,255,255,0.45)";
	ctx.beginPath();
	ctx.arc(f.x - r * .25, f.y - r * .25, r * .32, 0, Math.PI * 2);
	ctx.fill();
}
function drawFlag(ctx, flag, time, eaten, need) {
	const unlocked = flag.unlocked;
	ctx.save();
	ctx.translate(flag.x, flag.y);
	ctx.strokeStyle = unlocked ? "#d5dbd6" : "#5c665f";
	ctx.lineWidth = 3;
	ctx.lineCap = "round";
	ctx.beginPath();
	ctx.moveTo(0, 16);
	ctx.lineTo(0, -22);
	ctx.stroke();
	ctx.fillStyle = unlocked ? "#1c2621" : "#161c18";
	ctx.beginPath();
	ctx.arc(0, 16, 4, 0, Math.PI * 2);
	ctx.fill();
	const wave = Math.sin(time * 4) * (unlocked ? 4 : 1.5);
	ctx.beginPath();
	ctx.moveTo(1, -21);
	ctx.lineTo(26 + wave, -14);
	ctx.lineTo(1, -6);
	ctx.closePath();
	ctx.fillStyle = unlocked ? "#e8eee9" : "#3a4440";
	ctx.fill();
	if (unlocked) {
		ctx.fillStyle = "#5ecf9a";
		ctx.beginPath();
		ctx.moveTo(6, -18);
		ctx.lineTo(12, -15.5);
		ctx.lineTo(6, -13);
		ctx.closePath();
		ctx.fill();
	} else {
		ctx.fillStyle = "#8b958d";
		ctx.font = "600 9px Figtree, sans-serif";
		ctx.textAlign = "center";
		ctx.fillText(`${Math.min(eaten, need)}/${need}`, 0, 28);
	}
	if (unlocked) {
		const glow = ctx.createRadialGradient(0, -12, 2, 0, -12, 36);
		glow.addColorStop(0, "rgba(94,207,154,0.16)");
		glow.addColorStop(1, "rgba(94,207,154,0)");
		ctx.fillStyle = glow;
		ctx.beginPath();
		ctx.arc(0, -8, 36, 0, Math.PI * 2);
		ctx.fill();
	}
	ctx.restore();
}
function drawSnake(ctx, snake, world) {
	const pts = snake.points;
	if (pts.length < 2) return;
	const headR = world.headRadius(snake) * (1 + snake.pulse * .12);
	for (let i = pts.length - 1; i >= 0; i--) {
		const t = i / Math.max(1, pts.length - 1);
		const p = pts[i];
		const r = lerp(3.2, headR, Math.pow(t, .55));
		ctx.fillStyle = t > .72 ? snake.palette.body : t > .35 ? snake.palette.mid : snake.palette.tail;
		ctx.beginPath();
		ctx.arc(p.x, p.y, r, 0, Math.PI * 2);
		ctx.fill();
	}
	const head = pts[0];
	const fx = -Math.sin(snake.yaw);
	const fy = -Math.cos(snake.yaw);
	const lx = fy;
	const ly = -fx;
	ctx.fillStyle = "rgba(232,238,233,0.18)";
	ctx.beginPath();
	ctx.arc(head.x + fx * headR * .15, head.y + fy * headR * .15, headR * .55, 0, Math.PI * 2);
	ctx.fill();
	const eyeR = Math.max(2.1, headR * .28);
	const pupil = eyeR * .46;
	const e1 = {
		x: head.x + fx * headR * .32 + lx * headR * .38,
		y: head.y + fy * headR * .32 + ly * headR * .38
	};
	const e2 = {
		x: head.x + fx * headR * .32 - lx * headR * .38,
		y: head.y + fy * headR * .32 - ly * headR * .38
	};
	for (const e of [e1, e2]) {
		ctx.fillStyle = "#e8eee9";
		ctx.beginPath();
		ctx.arc(e.x, e.y, eyeR, 0, Math.PI * 2);
		ctx.fill();
		ctx.fillStyle = snake.palette.eye;
		ctx.beginPath();
		ctx.arc(e.x + fx * pupil * .7, e.y + fy * pupil * .7, pupil, 0, Math.PI * 2);
		ctx.fill();
	}
}
function drawFx(ctx, world) {
	for (const p of world.particles) {
		const a = Math.max(0, p.life / p.max);
		ctx.globalAlpha = a;
		ctx.fillStyle = p.color;
		ctx.beginPath();
		ctx.arc(p.x, p.y, p.r * a, 0, Math.PI * 2);
		ctx.fill();
	}
	ctx.globalAlpha = 1;
	ctx.font = "600 12px Figtree, sans-serif";
	ctx.textAlign = "center";
	for (const p of world.pops) {
		ctx.globalAlpha = Math.max(0, p.life / p.max);
		ctx.fillStyle = "#e8eee9";
		ctx.fillText(p.text, p.x, p.y);
	}
	ctx.globalAlpha = 1;
}
function lerp(a, b, t) {
	return a + (b - a) * t;
}
function roundRect(ctx, x, y, w, h, r) {
	const rr = Math.min(r, w / 2, h / 2);
	ctx.beginPath();
	ctx.moveTo(x + rr, y);
	ctx.arcTo(x + w, y, x + w, y + h, rr);
	ctx.arcTo(x + w, y + h, x, y + h, rr);
	ctx.arcTo(x, y + h, x, y, rr);
	ctx.arcTo(x, y, x + w, y, rr);
	ctx.closePath();
}
var KEY = "coilbound-v1";
var FALLBACK = {
	version: 1,
	unlocked: 1,
	best: [
		0,
		0,
		0,
		0,
		0
	],
	muted: false
};
function loadSave() {
	try {
		const raw = localStorage.getItem(KEY);
		if (!raw) return {
			...FALLBACK,
			best: [...FALLBACK.best]
		};
		const parsed = JSON.parse(raw);
		if (parsed.version !== 1) return {
			...FALLBACK,
			best: [...FALLBACK.best]
		};
		return {
			version: 1,
			unlocked: Math.max(1, Math.min(5, parsed.unlocked ?? 1)),
			best: Array.from({ length: 5 }, (_, i) => Math.max(0, parsed.best?.[i] ?? 0)),
			muted: Boolean(parsed.muted)
		};
	} catch {
		return {
			...FALLBACK,
			best: [...FALLBACK.best]
		};
	}
}
function writeSave(data) {
	try {
		localStorage.setItem(KEY, JSON.stringify(data));
	} catch {}
}
function wrapAngle(a) {
	while (a > Math.PI) a -= Math.PI * 2;
	while (a < -Math.PI) a += Math.PI * 2;
	return a;
}
function dist2(a, b) {
	const dx = a.x - b.x;
	const dy = a.y - b.y;
	return dx * dx + dy * dy;
}
function circleRect(cx, cy, r, rx, ry, rw, rh) {
	const nx = Math.max(rx, Math.min(cx, rx + rw));
	const ny = Math.max(ry, Math.min(cy, ry + rh));
	const dx = cx - nx;
	const dy = cy - ny;
	return dx * dx + dy * dy < r * r;
}
function makeSnake(id, isPlayer, x, y, yaw, length, palette, cruise) {
	const fx = -Math.sin(yaw);
	const fy = -Math.cos(yaw);
	const points = [];
	const n = Math.max(6, Math.ceil(length / 5));
	for (let i = 0; i < n; i++) points.push({
		x: x - fx * i * 5,
		y: y - fy * i * 5
	});
	return {
		id,
		isPlayer,
		points,
		yaw,
		speed: cruise,
		length,
		alive: true,
		palette,
		pulse: 0,
		think: Math.random() * .2,
		desiredYaw: yaw,
		grace: .7,
		boost: 0,
		cruise
	};
}
var World = class {
	level;
	snakes = [];
	food = [];
	particles = [];
	pops = [];
	flag = {
		x: 0,
		y: 0,
		unlocked: false
	};
	score = 0;
	eaten = 0;
	combo = 0;
	comboTimer = 0;
	time = 0;
	attract = false;
	trauma = 0;
	hitstop = 0;
	reducedMotion = false;
	nextId = 1;
	constructor(levelId, attract = false) {
		this.level = getLevel(levelId);
		this.attract = attract;
		const spawn = tileCenter(this.level, this.level.player.x, this.level.player.y);
		this.snakes.push(makeSnake(this.nextId++, !attract, spawn.x, spawn.y, this.level.player.yaw, 56, PLAYER_PALETTE, this.level.baseSpeed));
		for (const e of this.level.enemies) {
			const p = tileCenter(this.level, e.x, e.y);
			this.snakes.push(makeSnake(this.nextId++, false, p.x, p.y, e.yaw, e.length, e.palette, e.speed));
		}
		const fp = tileCenter(this.level, this.level.flag.x, this.level.flag.y);
		this.flag = {
			x: fp.x,
			y: fp.y,
			unlocked: false
		};
		for (let i = 0; i < this.level.foodCount; i++) this.spawnFood();
	}
	player() {
		return this.snakes.find((s) => s.isPlayer);
	}
	worldSize() {
		return {
			w: this.level.cols * this.level.tile,
			h: this.level.rows * this.level.tile
		};
	}
	headRadius(snake) {
		return 9 + Math.min(4, snake.length / 90);
	}
	step(dt, actions) {
		let event = "none";
		let scoreDelta = 0;
		if (this.hitstop > 0) {
			this.hitstop = Math.max(0, this.hitstop - dt);
			this.tickFx(dt * .4);
			return {
				event,
				scoreDelta
			};
		}
		this.time += dt;
		this.comboTimer = Math.max(0, this.comboTimer - dt);
		if (this.comboTimer <= 0) this.combo = 0;
		this.trauma = Math.max(0, this.trauma - dt * 1.6);
		for (const snake of this.snakes) {
			if (!snake.alive) continue;
			snake.grace = Math.max(0, snake.grace - dt);
			snake.pulse = Math.max(0, snake.pulse - dt * 3);
			if (snake.isPlayer && !this.attract) this.steerPlayer(snake, actions, dt);
			else this.steerAi(snake, dt);
			this.advance(snake, dt);
		}
		this.resolveEats((kind, d) => {
			if (kind === "eat") {
				event = "eat";
				scoreDelta += d;
			}
		});
		this.resolveCollisions(() => {
			event = "burst";
		});
		if (!this.flag.unlocked && this.eaten >= this.level.foodToUnlock) {
			this.flag.unlocked = true;
			event = "unlock";
			this.addTrauma(.4);
		}
		const player = this.player();
		if (player?.alive && this.flag.unlocked && !this.attract) {
			const hr = this.headRadius(player);
			const head = player.points[0];
			if (head && dist2(head, this.flag) < (hr + 16) * (hr + 16)) {
				event = "win";
				const bonus = 200 * this.level.id + Math.round(player.length);
				this.score += bonus;
				scoreDelta += bonus;
				player.alive = true;
			}
		}
		this.maintainFood();
		this.tickFx(dt);
		return {
			event,
			scoreDelta
		};
	}
	steerPlayer(snake, actions, dt) {
		snake.yaw += actions.steer * this.level.turnRate * dt;
		snake.yaw = wrapAngle(snake.yaw);
		const target = actions.brake ? this.level.brakeSpeed : actions.boost ? this.level.boostSpeed : this.level.baseSpeed;
		snake.speed += (target - snake.speed) * (1 - Math.exp(-14 * dt));
		snake.boost = actions.boost ? 1 : 0;
	}
	steerAi(snake, dt) {
		snake.think -= dt;
		if (snake.think <= 0) {
			snake.think = .16 + Math.random() * .22;
			snake.desiredYaw = this.pickAiYaw(snake);
		}
		const err = wrapAngle(snake.desiredYaw - snake.yaw);
		const turn = Math.max(-1, Math.min(1, err / .35));
		snake.yaw += turn * this.level.turnRate * .92 * dt;
		snake.yaw = wrapAngle(snake.yaw);
		const target = this.look(snake, 54, snake.yaw) < .4 ? snake.cruise * .82 : snake.cruise;
		snake.speed += (target - snake.speed) * (1 - Math.exp(-10 * dt));
	}
	pickAiYaw(snake) {
		const head = snake.points[0];
		if (!head) return snake.yaw;
		const samples = [
			0,
			.7,
			-.7,
			1.2,
			-1.2,
			1.8,
			-1.8
		];
		let best = snake.yaw;
		let bestScore = -Infinity;
		for (const off of samples) {
			const yaw = wrapAngle(snake.yaw + off);
			let score = this.look(snake, 90, yaw) * 4;
			const fx = -Math.sin(yaw);
			const fy = -Math.cos(yaw);
			let foodBonus = 0;
			for (const f of this.food) {
				const dx = f.x - head.x;
				const dy = f.y - head.y;
				const d = Math.hypot(dx, dy);
				if (d < 220 && dx * fx + dy * fy > 0) foodBonus = Math.max(foodBonus, (220 - d) / 220);
			}
			score += foodBonus * 2.2;
			if (off === 0) score += .15;
			if (score > bestScore) {
				bestScore = score;
				best = yaw;
			}
		}
		const hunger = this.food[0];
		if (hunger && Math.random() < .45) {
			const yawTo = Math.atan2(-(hunger.x - head.x), -(hunger.y - head.y));
			if (this.look(snake, 70, yawTo) > .35) best = yawTo;
		}
		return best;
	}
	look(snake, dist, yaw) {
		const head = snake.points[0];
		if (!head) return 0;
		const fx = -Math.sin(yaw);
		const fy = -Math.cos(yaw);
		const steps = 5;
		for (let i = 1; i <= steps; i++) {
			const t = i / steps * dist;
			const p = {
				x: head.x + fx * t,
				y: head.y + fy * t
			};
			if (this.hitsWall(p.x, p.y, 8)) return (i - 1) / steps;
			if (this.hitsAnyBody(p, snake.id, 8)) return (i - 1) / steps;
		}
		return 1;
	}
	advance(snake, dt) {
		const head = snake.points[0];
		if (!head) return;
		const dist = snake.speed * dt;
		const fx = -Math.sin(snake.yaw);
		const fy = -Math.cos(snake.yaw);
		const nx = head.x + fx * dist;
		const ny = head.y + fy * dist;
		snake.points.unshift({
			x: nx,
			y: ny
		});
		let acc = 0;
		let keep = 1;
		for (let i = 1; i < snake.points.length; i++) {
			const a = snake.points[i - 1];
			const b = snake.points[i];
			acc += Math.hypot(a.x - b.x, a.y - b.y);
			keep = i + 1;
			if (acc >= snake.length) break;
		}
		if (keep < snake.points.length) snake.points.length = keep;
		if (snake.points.length > 280) snake.points.length = 280;
	}
	resolveEats(onEat) {
		for (const snake of this.snakes) {
			if (!snake.alive) continue;
			const head = snake.points[0];
			if (!head) continue;
			const hr = this.headRadius(snake);
			for (let i = this.food.length - 1; i >= 0; i--) {
				const f = this.food[i];
				if (dist2(head, f) > (hr + f.r) * (hr + f.r)) continue;
				this.food.splice(i, 1);
				snake.length += 16 + f.value * 4;
				snake.pulse = 1;
				if (snake.isPlayer) {
					this.combo += 1;
					this.comboTimer = .9;
					const gained = (10 + f.value * 5) * Math.min(4, this.combo);
					this.score += gained;
					this.eaten += 1;
					this.pops.push({
						x: head.x,
						y: head.y - 12,
						text: `+${gained}`,
						life: .7,
						max: .7
					});
					this.emit(head.x, head.y, snake.palette.body, 10, 70);
					this.addTrauma(.18);
					this.hitstop = this.reducedMotion ? 0 : .03;
					onEat("eat", gained);
				} else this.emit(head.x, head.y, snake.palette.body, 6, 50);
			}
		}
	}
	resolveCollisions(onBurst) {
		const dying = [];
		for (const snake of this.snakes) {
			if (!snake.alive || snake.grace > 0) continue;
			const head = snake.points[0];
			if (!head) continue;
			const hr = this.headRadius(snake);
			if (this.hitsWall(head.x, head.y, hr * .82)) {
				dying.push(snake);
				continue;
			}
			if (this.hitsAnyBody(head, snake.id, hr * .78, snake)) dying.push(snake);
		}
		for (const snake of dying) {
			if (!snake.alive) continue;
			snake.alive = false;
			this.burstSnake(snake);
			if (snake.isPlayer) {
				this.addTrauma(.75);
				this.hitstop = this.reducedMotion ? 0 : .08;
				onBurst();
			} else this.addTrauma(.32);
		}
	}
	hitsWall(x, y, r) {
		const t = this.level.tile;
		const minC = Math.floor((x - r) / t);
		const maxC = Math.floor((x + r) / t);
		const minR = Math.floor((y - r) / t);
		const maxR = Math.floor((y + r) / t);
		for (let c = minC; c <= maxC; c++) for (let row = minR; row <= maxR; row++) {
			if (!isWall(this.level, c, row)) continue;
			if (circleRect(x, y, r, c * t, row * t, t, t)) return true;
		}
		return false;
	}
	hitsAnyBody(p, selfId, r, self) {
		for (const other of this.snakes) {
			if (!other.alive) continue;
			let start = 0;
			if (other.id === selfId) start = this.skipOwn(other);
			for (let i = start; i < other.points.length; i += 2) {
				const q = other.points[i];
				const br = other.id === selfId ? r * .7 : 7;
				if (dist2(p, q) < (r + br) * (r + br)) {
					if (self && other.id === selfId && i < 10) continue;
					return true;
				}
			}
		}
		return false;
	}
	skipOwn(snake) {
		if (!snake.points[0]) return 12;
		let acc = 0;
		for (let i = 1; i < snake.points.length; i++) {
			const a = snake.points[i - 1];
			const b = snake.points[i];
			acc += Math.hypot(a.x - b.x, a.y - b.y);
			if (acc > 28) return i;
		}
		return snake.points.length;
	}
	burstSnake(snake) {
		const pts = snake.points;
		for (let i = 0; i < pts.length; i += 3) {
			const p = pts[i];
			if (this.hitsWall(p.x, p.y, 6)) continue;
			this.food.push({
				x: p.x + (Math.random() - .5) * 6,
				y: p.y + (Math.random() - .5) * 6,
				r: 6 + Math.random() * 3,
				value: 2,
				seed: Math.random() * 10
			});
		}
		const head = pts[0];
		if (head) this.emit(head.x, head.y, snake.palette.body, 28, 160);
		for (let i = 0; i < pts.length; i += 4) {
			const p = pts[i];
			this.emit(p.x, p.y, snake.palette.mid, 4, 80);
		}
	}
	maintainFood() {
		let guard = 12;
		while (this.food.length < this.level.foodCount && guard-- > 0) this.spawnFood();
	}
	spawnFood() {
		const t = this.level.tile;
		for (let k = 0; k < 30; k++) {
			const c = 1 + Math.floor(Math.random() * (this.level.cols - 2));
			const r = 1 + Math.floor(Math.random() * (this.level.rows - 2));
			if (isWall(this.level, c, r)) continue;
			const p = tileCenter(this.level, c, r);
			if (dist2(p, this.flag) < 1600) continue;
			let near = false;
			for (const s of this.snakes) {
				if (!s.alive) continue;
				const h = s.points[0];
				if (h && dist2(h, p) < 2500) near = true;
			}
			if (near) continue;
			this.food.push({
				x: p.x + (Math.random() - .5) * (t * .3),
				y: p.y + (Math.random() - .5) * (t * .3),
				r: 5.5,
				value: 1,
				seed: Math.random() * 10
			});
			return;
		}
	}
	emit(x, y, color, n, speed) {
		if (this.reducedMotion) n = Math.min(n, 6);
		const cap = 220;
		for (let i = 0; i < n; i++) {
			if (this.particles.length >= cap) this.particles.shift();
			const a = Math.random() * Math.PI * 2;
			const s = speed * (.3 + Math.random() * .7);
			this.particles.push({
				x,
				y,
				vx: Math.cos(a) * s,
				vy: Math.sin(a) * s,
				life: .35 + Math.random() * .35,
				max: .7,
				r: 1.6 + Math.random() * 2.4,
				color
			});
		}
	}
	tickFx(dt) {
		for (let i = this.particles.length - 1; i >= 0; i--) {
			const p = this.particles[i];
			p.life -= dt;
			p.x += p.vx * dt;
			p.y += p.vy * dt;
			p.vx *= .92;
			p.vy *= .92;
			if (p.life <= 0) this.particles.splice(i, 1);
		}
		for (let i = this.pops.length - 1; i >= 0; i--) {
			const p = this.pops[i];
			p.life -= dt;
			p.y -= 28 * dt;
			if (p.life <= 0) this.pops.splice(i, 1);
		}
	}
	addTrauma(v) {
		if (this.reducedMotion) return;
		this.trauma = Math.min(1, this.trauma + v);
	}
};
var GameEngine = class {
	canvas;
	ctx;
	input = new Input();
	audio = new AudioBus();
	world;
	cam = createCam();
	raf = 0;
	acc = 0;
	last = 0;
	running = false;
	dpr = 1;
	viewW = 1;
	viewH = 1;
	save;
	phase = "title";
	levelId = 1;
	onHud;
	reducedMotion = false;
	resizeObs = null;
	constructor(canvas, onHud) {
		this.canvas = canvas;
		const ctx = canvas.getContext("2d");
		if (!ctx) throw new Error("Canvas 2D unavailable");
		this.ctx = ctx;
		this.onHud = onHud;
		this.save = loadSave();
		this.audio.setMuted(this.save.muted);
		this.reducedMotion = window.matchMedia?.("(prefers-reduced-motion: reduce)").matches ?? false;
		this.world = new World(1, true);
		this.world.reducedMotion = this.reducedMotion;
		this.input.attach();
		this.bindProbe();
		this.watchSize();
		this.emitHud();
	}
	start() {
		if (this.running) return;
		this.running = true;
		this.last = performance.now();
		this.raf = requestAnimationFrame(this.frame);
	}
	destroy() {
		this.running = false;
		cancelAnimationFrame(this.raf);
		this.input.detach();
		this.resizeObs?.disconnect();
		if (window.__controlsTest) delete window.__controlsTest;
	}
	unlockAudio() {
		this.audio.unlock();
	}
	playLevel(id) {
		this.audio.unlock();
		this.audio.click();
		this.levelId = id;
		this.world = new World(id, false);
		this.world.reducedMotion = this.reducedMotion;
		const p = this.world.player()?.points[0];
		if (p) {
			this.cam.x = p.x;
			this.cam.y = p.y;
		}
		this.phase = "play";
		this.emitHud();
	}
	openLevels() {
		this.audio.unlock();
		this.audio.click();
		this.phase = "levels";
		this.ensureAttract();
		this.emitHud();
	}
	backToTitle() {
		this.audio.click();
		this.phase = "title";
		this.ensureAttract();
		this.emitHud();
	}
	togglePause() {
		if (this.phase === "play") {
			this.phase = "pause";
			this.emitHud();
		} else if (this.phase === "pause") {
			this.phase = "play";
			this.emitHud();
		}
	}
	toggleMute() {
		this.save.muted = !this.save.muted;
		this.audio.setMuted(this.save.muted);
		writeSave(this.save);
		this.emitHud();
	}
	setTouchSteer(v) {
		this.input.touchSteer = v;
	}
	setTouchBoost(v) {
		this.input.touchBoost = v;
	}
	setTouchBrake(v) {
		this.input.touchBrake = v;
	}
	ensureAttract() {
		if (!this.world.attract) {
			this.world = new World(1, true);
			this.world.reducedMotion = this.reducedMotion;
		}
	}
	frame = (now) => {
		if (!this.running) return;
		const dt = Math.min(.1, (now - this.last) / 1e3);
		this.last = now;
		this.acc += dt;
		const step = 1 / 60;
		const actions = this.input.sample();
		if (this.input.pausePressed && (this.phase === "play" || this.phase === "pause")) this.togglePause();
		const simulating = this.phase === "play" || this.phase === "title" || this.phase === "levels";
		while (this.acc >= step) {
			if (simulating) {
				const playerActions = this.phase === "play" ? actions : {
					steer: 0,
					boost: false,
					brake: false,
					pause: false,
					confirm: false
				};
				const result = this.world.step(step, playerActions);
				if (this.phase === "play") this.handleEvent(result.event);
			}
			this.acc -= step;
		}
		const player = this.world.player();
		const follow = this.phase === "play" && player?.points[0] ? player.points[0] : this.world.snakes.find((s) => s.alive)?.points[0] ?? null;
		computeCam(this.world, this.viewW, this.viewH, follow, dt, this.cam);
		drawWorld(this.ctx, this.world, this.viewW, this.viewH, this.cam, this.dpr);
		this.raf = requestAnimationFrame(this.frame);
	};
	handleEvent(event) {
		if (event === "eat") this.audio.eat();
		if (event === "burst") {
			this.audio.burst();
			this.phase = "dead";
			this.emitHud();
		}
		if (event === "unlock") this.audio.unlockFlag();
		if (event === "win") {
			this.audio.win();
			const idx = this.levelId - 1;
			this.save.best[idx] = Math.max(this.save.best[idx] ?? 0, this.world.score);
			this.save.unlocked = Math.max(this.save.unlocked, Math.min(TOTAL_LEVELS, this.levelId + 1));
			writeSave(this.save);
			this.phase = "win";
			this.emitHud();
		}
		if (event === "eat" || event === "unlock") this.emitHud();
	}
	watchSize() {
		const apply = () => {
			const rect = (this.canvas.parentElement ?? this.canvas).getBoundingClientRect();
			this.viewW = Math.max(1, rect.width);
			this.viewH = Math.max(1, rect.height);
			this.dpr = Math.min(2, window.devicePixelRatio || 1);
			this.canvas.width = Math.floor(this.viewW * this.dpr);
			this.canvas.height = Math.floor(this.viewH * this.dpr);
			this.canvas.style.width = `${this.viewW}px`;
			this.canvas.style.height = `${this.viewH}px`;
		};
		apply();
		this.resizeObs = new ResizeObserver(apply);
		this.resizeObs.observe(this.canvas.parentElement ?? this.canvas);
	}
	emitHud() {
		const player = this.world.player();
		const length = player ? Math.max(3, Math.round(player.length / 14)) : 3;
		this.onHud({
			phase: this.phase,
			levelId: this.levelId,
			levelName: this.world.attract ? "Coilbound" : this.world.level.name,
			score: this.world.score,
			length,
			eaten: this.world.eaten,
			need: this.world.level.foodToUnlock,
			flagReady: this.world.flag.unlocked,
			unlocked: this.save.unlocked,
			best: this.save.best[this.levelId - 1] ?? 0,
			muted: this.save.muted,
			totalLevels: TOTAL_LEVELS
		});
	}
	getSave() {
		return this.save;
	}
	bindProbe() {
		window.__controlsTest = {
			getYaw: () => this.world.player()?.yaw ?? 0,
			getSpeed: () => this.world.player()?.speed ?? 0,
			setKeys: (codes) => {
				if (this.phase !== "play") this.playLevel(this.levelId || 1);
				this.input.setKeys(codes);
			},
			setSteer: (v) => {
				this.input.injectedSteer = v;
			}
		};
	}
};
var INITIAL = {
	phase: "title",
	levelId: 1,
	levelName: "Coilbound",
	score: 0,
	length: 3,
	eaten: 0,
	need: 8,
	flagReady: false,
	unlocked: 1,
	best: 0,
	muted: false,
	totalLevels: 5
};
function GameApp() {
	const canvasRef = (0, import_react.useRef)(null);
	const [engine, setEngine] = (0, import_react.useState)(null);
	const [hud, setHud] = (0, import_react.useState)(INITIAL);
	const [coarse, setCoarse] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const canvas = canvasRef.current;
		if (!canvas) return;
		const next = new GameEngine(canvas, setHud);
		setEngine(next);
		next.start();
		const mq = window.matchMedia("(pointer: coarse)");
		const sync = () => setCoarse(mq.matches);
		sync();
		mq.addEventListener?.("change", sync);
		const onVis = () => {
			if (document.visibilityState === "visible") next.unlockAudio();
		};
		document.addEventListener("visibilitychange", onVis);
		return () => {
			mq.removeEventListener?.("change", sync);
			document.removeEventListener("visibilitychange", onVis);
			next.destroy();
			setEngine(null);
		};
	}, []);
	const playing = hud.phase === "play";
	const showOverlay = [
		"title",
		"levels",
		"pause",
		"dead",
		"win"
	].includes(hud.phase);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "relative h-dvh w-full overflow-hidden bg-bg text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
				ref: canvasRef,
				className: "absolute inset-0 h-full w-full touch-none",
				onPointerDown: () => engine?.unlockAudio()
			}),
			playing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hud, {
				hud,
				engine
			}) : null,
			playing && coarse ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TouchPad, { engine }) : null,
			showOverlay ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "overlay-backdrop absolute inset-0 flex items-end justify-center bg-bg/70 p-4 pt-[max(1rem,env(safe-area-inset-top))] pb-[max(1.25rem,env(safe-area-inset-bottom))] sm:items-center",
				children: [
					hud.phase === "title" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TitleCard, {
						hud,
						engine
					}) : null,
					hud.phase === "levels" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LevelCard, {
						hud,
						engine
					}) : null,
					hud.phase === "pause" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PauseCard, {
						hud,
						engine
					}) : null,
					hud.phase === "dead" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DeadCard, {
						hud,
						engine
					}) : null,
					hud.phase === "win" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WinCard, {
						hud,
						engine
					}) : null
				]
			}) : null
		]
	});
}
function Hud({ hud, engine }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "pointer-events-none absolute inset-x-0 top-0 z-10 flex items-start justify-between gap-3 p-3 pt-[max(0.75rem,env(safe-area-inset-top))] sm:p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					label: "Score",
					value: hud.score.toString()
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					label: "Length",
					value: hud.length.toString()
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "pointer-events-none max-w-[42%] text-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-sm font-medium tracking-tight text-fg",
					children: hud.levelName
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-0.5 flex items-center justify-center gap-1 text-xs text-muted",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Flag, {
						className: "size-3.5",
						strokeWidth: 2
					}), hud.flagReady ? "Banner open" : `${hud.eaten}/${hud.need} to unlock`]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "pointer-events-auto flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "secondary",
					size: "icon",
					"aria-label": hud.muted ? "Unmute" : "Mute",
					onClick: () => engine?.toggleMute(),
					children: hud.muted ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VolumeX, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Volume2, { className: "size-4" })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "secondary",
					size: "icon",
					"aria-label": "Pause",
					onClick: () => engine?.togglePause(),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, { className: "size-4" })
				})]
			})
		]
	});
}
function Stat({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-w-[4.5rem] rounded-lg border border-border bg-surface/90 px-3 py-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-[0.65rem] font-medium tracking-wide text-muted uppercase",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-display tabular text-lg leading-tight font-semibold tracking-tight",
			children: value
		})]
	});
}
function Panel({ children, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: cn("overlay-panel w-full max-w-md rounded-2xl border border-border bg-surface p-6 shadow-[0_24px_60px_rgba(0,0,0,0.35)]", className),
		children
	});
}
function TitleCard({ hud, engine }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs font-medium tracking-[0.18em] text-muted uppercase",
			children: "Arena coil"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-display mt-2 text-4xl leading-none font-semibold tracking-tight",
			children: "Coilbound"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-3 text-sm leading-relaxed text-muted",
			children: "Grow from a short coil. Eat motes, outlast rival snakes, and claim the banner. Crash into a body and you burst into motes anyone can eat."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
			className: "mt-4 space-y-1.5 text-sm text-fg",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "w-16 shrink-0 text-muted",
						children: "Turn"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "A / D or arrows" })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "w-16 shrink-0 text-muted",
						children: "Boost"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "W / Up" })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "w-16 shrink-0 text-muted",
						children: "Brake"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "S / Down" })]
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-6 flex flex-col gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				size: "lg",
				className: "w-full",
				onClick: () => engine?.playLevel(1),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-4" }), "Start"]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				variant: "secondary",
				className: "w-full",
				onClick: () => engine?.openLevels(),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Map, { className: "size-4" }), "Levels"]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mt-4 text-center text-xs text-faint",
			children: ["Best this field ", hud.best || "—"]
		})
	] });
}
function LevelCard({ hud, engine }) {
	const save = engine?.getSave();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "font-display text-2xl font-semibold tracking-tight",
			children: "Levels"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-sm text-muted",
			children: "Clear a banner to open the next den."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-4 grid gap-2",
			children: LEVELS.map((level) => {
				const locked = level.id > (save?.unlocked ?? hud.unlocked);
				const best = save?.best[level.id - 1] ?? 0;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					disabled: locked,
					onClick: () => engine?.playLevel(level.id),
					className: cn("flex min-h-14 items-center gap-3 rounded-lg border px-3 py-2.5 text-left transition-colors", locked ? "border-border bg-bg text-faint" : "border-border bg-surface-2 text-fg hover:border-border-strong"),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-display w-6 text-lg font-semibold",
							children: level.id
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "min-w-0 flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block text-sm font-medium",
								children: level.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block truncate text-xs text-muted",
								children: level.blurb
							})]
						}),
						locked ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "size-4 shrink-0 text-faint" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "tabular text-xs text-muted",
							children: best ? best : ""
						})
					]
				}, level.id);
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			variant: "ghost",
			className: "mt-4 w-full",
			onClick: () => engine?.backToTitle(),
			children: "Back"
		})
	] });
}
function PauseCard({ hud, engine }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "font-display text-2xl font-semibold tracking-tight",
			children: "Paused"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mt-1 text-sm text-muted",
			children: [
				hud.levelName,
				" · score ",
				hud.score
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-5 flex flex-col gap-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "lg",
					className: "w-full",
					onClick: () => engine?.togglePause(),
					children: "Resume"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "secondary",
					className: "w-full",
					onClick: () => engine?.playLevel(hud.levelId),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "size-4" }), "Restart"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					className: "w-full",
					onClick: () => engine?.openLevels(),
					children: "Levels"
				})
			]
		})
	] });
}
function DeadCard({ hud, engine }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs font-medium tracking-[0.16em] text-muted uppercase",
			children: "Burst"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "font-display mt-1 text-3xl font-semibold tracking-tight",
			children: "You became motes"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-sm text-muted",
			children: "Hit a wall or a body and the coil comes apart. Rival snakes will feed."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-4 grid grid-cols-2 gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
				label: "Score",
				value: hud.score.toString()
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
				label: "Length",
				value: hud.length.toString()
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-5 flex flex-col gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				size: "lg",
				className: "w-full",
				onClick: () => engine?.playLevel(hud.levelId),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "size-4" }), "Restart"]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "secondary",
				className: "w-full",
				onClick: () => engine?.openLevels(),
				children: "Levels"
			})]
		})
	] });
}
function WinCard({ hud, engine }) {
	const last = hud.levelId >= hud.totalLevels;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs font-medium tracking-[0.16em] text-good uppercase",
			children: "Banner claimed"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "font-display mt-1 text-3xl font-semibold tracking-tight",
			children: last ? "Every den is yours" : hud.levelName
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-sm text-muted",
			children: last ? "Five banners, one coil. Run it again cleaner." : "The next den is open."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-4 grid grid-cols-2 gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
				label: "Score",
				value: hud.score.toString()
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
				label: "Best",
				value: (hud.best || hud.score).toString()
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-5 flex flex-col gap-2",
			children: [
				last ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "lg",
					className: "w-full",
					onClick: () => engine?.playLevel(hud.levelId + 1),
					children: "Next level"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: last ? "primary" : "secondary",
					size: "lg",
					className: "w-full",
					onClick: () => engine?.playLevel(hud.levelId),
					children: "Replay"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					className: "w-full",
					onClick: () => engine?.openLevels(),
					children: "Levels"
				})
			]
		})
	] });
}
function TouchPad({ engine }) {
	const held = (0, import_react.useRef)({
		left: false,
		right: false,
		boost: false,
		brake: false
	});
	const apply = () => {
		if (!engine) return;
		const h = held.current;
		engine.setTouchSteer((h.left ? 1 : 0) + (h.right ? -1 : 0));
		engine.setTouchBoost(h.boost);
		engine.setTouchBrake(h.brake);
	};
	const bind = (key) => ({
		onPointerDown: (e) => {
			e.currentTarget.setPointerCapture(e.pointerId);
			held.current[key] = true;
			apply();
		},
		onPointerUp: () => {
			held.current[key] = false;
			apply();
		},
		onPointerCancel: () => {
			held.current[key] = false;
			apply();
		}
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "pointer-events-none absolute inset-x-0 bottom-0 z-10 flex items-end justify-between px-4 pb-[max(1rem,env(safe-area-inset-bottom))]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "pointer-events-auto flex gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pad, {
				label: "Left",
				...bind("left")
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pad, {
				label: "Right",
				...bind("right")
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "pointer-events-auto flex gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pad, {
				label: "Brake",
				...bind("brake")
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pad, {
				label: "Boost",
				...bind("boost")
			})]
		})]
	});
}
function Pad({ label, ...rest }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		"aria-label": label,
		className: "h-14 min-w-14 rounded-xl border border-border bg-surface/85 px-4 text-xs font-medium text-fg backdrop-blur-sm",
		...rest,
		children: label
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GameApp, {});
}
//#endregion
export { Home as component };
