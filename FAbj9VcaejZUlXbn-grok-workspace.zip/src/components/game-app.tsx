import { useEffect, useRef, useState, type HTMLAttributes, type PointerEvent, type ReactNode } from "react";
import {
  Flag,
  Lock,
  Map,
  Pause,
  Play,
  RotateCcw,
  Volume2,
  VolumeX,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { GameEngine } from "@/game/engine";
import { LEVELS } from "@/game/levels";
import type { HudSnapshot, Phase } from "@/game/types";
import { cn } from "@/lib/utils";

const INITIAL: HudSnapshot = {
  phase: "title",
  levelId: 1,
  levelName: "Coilbound",
  score: 0,
  length: 3,
  eaten: 0,
  need: 8,
  flagReady: false,
  unlocked: 1,
  best: 0,
  muted: false,
  totalLevels: 5,
};

export function GameApp() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [engine, setEngine] = useState<GameEngine | null>(null);
  const [hud, setHud] = useState<HudSnapshot>(INITIAL);
  const [coarse, setCoarse] = useState(false);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const next = new GameEngine(canvas, setHud);
    setEngine(next);
    next.start();
    const mq = window.matchMedia("(pointer: coarse)");
    const sync = () => setCoarse(mq.matches);
    sync();
    mq.addEventListener?.("change", sync);
    const onVis = () => {
      if (document.visibilityState === "visible") next.unlockAudio();
    };
    document.addEventListener("visibilitychange", onVis);
    return () => {
      mq.removeEventListener?.("change", sync);
      document.removeEventListener("visibilitychange", onVis);
      next.destroy();
      setEngine(null);
    };
  }, []);
  const playing = hud.phase === "play";
  const overlay: Phase[] = ["title", "levels", "pause", "dead", "win"];
  const showOverlay = overlay.includes(hud.phase);

  return (
    <main className="relative h-dvh w-full overflow-hidden bg-bg text-fg">
      <canvas
        ref={canvasRef}
        className="absolute inset-0 h-full w-full touch-none"
        onPointerDown={() => engine?.unlockAudio()}
      />

      {playing ? <Hud hud={hud} engine={engine} /> : null}

      {playing && coarse ? <TouchPad engine={engine} /> : null}

      {showOverlay ? (
        <div className="overlay-backdrop absolute inset-0 flex items-end justify-center bg-bg/70 p-4 pt-[max(1rem,env(safe-area-inset-top))] pb-[max(1.25rem,env(safe-area-inset-bottom))] sm:items-center">
          {hud.phase === "title" ? <TitleCard hud={hud} engine={engine} /> : null}
          {hud.phase === "levels" ? <LevelCard hud={hud} engine={engine} /> : null}
          {hud.phase === "pause" ? <PauseCard hud={hud} engine={engine} /> : null}
          {hud.phase === "dead" ? <DeadCard hud={hud} engine={engine} /> : null}
          {hud.phase === "win" ? <WinCard hud={hud} engine={engine} /> : null}
        </div>
      ) : null}
    </main>
  );
}

function Hud({ hud, engine }: { hud: HudSnapshot; engine: GameEngine | null }) {
  return (
    <div className="pointer-events-none absolute inset-x-0 top-0 z-10 flex items-start justify-between gap-3 p-3 pt-[max(0.75rem,env(safe-area-inset-top))] sm:p-4">
      <div className="flex gap-2">
        <Stat label="Score" value={hud.score.toString()} />
        <Stat label="Length" value={hud.length.toString()} />
      </div>
      <div className="pointer-events-none max-w-[42%] text-center">
        <p className="font-display text-sm font-medium tracking-tight text-fg">{hud.levelName}</p>
        <p className="mt-0.5 flex items-center justify-center gap-1 text-xs text-muted">
          <Flag className="size-3.5" strokeWidth={2} />
          {hud.flagReady ? "Banner open" : `${hud.eaten}/${hud.need} to unlock`}
        </p>
      </div>
      <div className="pointer-events-auto flex gap-2">
        <Button
          variant="secondary"
          size="icon"
          aria-label={hud.muted ? "Unmute" : "Mute"}
          onClick={() => engine?.toggleMute()}
        >
          {hud.muted ? <VolumeX className="size-4" /> : <Volume2 className="size-4" />}
        </Button>
        <Button variant="secondary" size="icon" aria-label="Pause" onClick={() => engine?.togglePause()}>
          <Pause className="size-4" />
        </Button>
      </div>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="min-w-[4.5rem] rounded-lg border border-border bg-surface/90 px-3 py-2">
      <p className="text-[0.65rem] font-medium tracking-wide text-muted uppercase">{label}</p>
      <p className="font-display tabular text-lg leading-tight font-semibold tracking-tight">{value}</p>
    </div>
  );
}

function Panel({ children, className }: { children: ReactNode; className?: string }) {
  return (
    <section
      className={cn(
        "overlay-panel w-full max-w-md rounded-2xl border border-border bg-surface p-6 shadow-[0_24px_60px_rgba(0,0,0,0.35)]",
        className,
      )}
    >
      {children}
    </section>
  );
}

function TitleCard({ hud, engine }: { hud: HudSnapshot; engine: GameEngine | null }) {
  return (
    <Panel>
      <p className="text-xs font-medium tracking-[0.18em] text-muted uppercase">Arena coil</p>
      <h1 className="font-display mt-2 text-4xl leading-none font-semibold tracking-tight">Coilbound</h1>
      <p className="mt-3 text-sm leading-relaxed text-muted">
        Grow from a short coil. Eat motes, outlast rival snakes, and claim the banner. Crash into a
        body and you burst into motes anyone can eat.
      </p>
      <ul className="mt-4 space-y-1.5 text-sm text-fg">
        <li className="flex gap-2">
          <span className="w-16 shrink-0 text-muted">Turn</span>
          <span>A / D or arrows</span>
        </li>
        <li className="flex gap-2">
          <span className="w-16 shrink-0 text-muted">Boost</span>
          <span>W / Up</span>
        </li>
        <li className="flex gap-2">
          <span className="w-16 shrink-0 text-muted">Brake</span>
          <span>S / Down</span>
        </li>
      </ul>
      <div className="mt-6 flex flex-col gap-2">
        <Button size="lg" className="w-full" onClick={() => engine?.playLevel(1)}>
          <Play className="size-4" />
          Start
        </Button>
        <Button variant="secondary" className="w-full" onClick={() => engine?.openLevels()}>
          <Map className="size-4" />
          Levels
        </Button>
      </div>
      <p className="mt-4 text-center text-xs text-faint">Best this field {hud.best || "—"}</p>
    </Panel>
  );
}

function LevelCard({ hud, engine }: { hud: HudSnapshot; engine: GameEngine | null }) {
  const save = engine?.getSave();
  return (
    <Panel>
      <h2 className="font-display text-2xl font-semibold tracking-tight">Levels</h2>
      <p className="mt-1 text-sm text-muted">Clear a banner to open the next den.</p>
      <div className="mt-4 grid gap-2">
        {LEVELS.map((level) => {
          const locked = level.id > (save?.unlocked ?? hud.unlocked);
          const best = save?.best[level.id - 1] ?? 0;
          return (
            <button
              key={level.id}
              type="button"
              disabled={locked}
              onClick={() => engine?.playLevel(level.id)}
              className={cn(
                "flex min-h-14 items-center gap-3 rounded-lg border px-3 py-2.5 text-left transition-colors",
                locked
                  ? "border-border bg-bg text-faint"
                  : "border-border bg-surface-2 text-fg hover:border-border-strong",
              )}
            >
              <span className="font-display w-6 text-lg font-semibold">{level.id}</span>
              <span className="min-w-0 flex-1">
                <span className="block text-sm font-medium">{level.name}</span>
                <span className="block truncate text-xs text-muted">{level.blurb}</span>
              </span>
              {locked ? (
                <Lock className="size-4 shrink-0 text-faint" />
              ) : (
                <span className="tabular text-xs text-muted">{best ? best : ""}</span>
              )}
            </button>
          );
        })}
      </div>
      <Button variant="ghost" className="mt-4 w-full" onClick={() => engine?.backToTitle()}>
        Back
      </Button>
    </Panel>
  );
}

function PauseCard({ hud, engine }: { hud: HudSnapshot; engine: GameEngine | null }) {
  return (
    <Panel>
      <h2 className="font-display text-2xl font-semibold tracking-tight">Paused</h2>
      <p className="mt-1 text-sm text-muted">
        {hud.levelName} · score {hud.score}
      </p>
      <div className="mt-5 flex flex-col gap-2">
        <Button size="lg" className="w-full" onClick={() => engine?.togglePause()}>
          Resume
        </Button>
        <Button variant="secondary" className="w-full" onClick={() => engine?.playLevel(hud.levelId)}>
          <RotateCcw className="size-4" />
          Restart
        </Button>
        <Button variant="ghost" className="w-full" onClick={() => engine?.openLevels()}>
          Levels
        </Button>
      </div>
    </Panel>
  );
}

function DeadCard({ hud, engine }: { hud: HudSnapshot; engine: GameEngine | null }) {
  return (
    <Panel>
      <p className="text-xs font-medium tracking-[0.16em] text-muted uppercase">Burst</p>
      <h2 className="font-display mt-1 text-3xl font-semibold tracking-tight">You became motes</h2>
      <p className="mt-2 text-sm text-muted">Hit a wall or a body and the coil comes apart. Rival snakes will feed.</p>
      <div className="mt-4 grid grid-cols-2 gap-2">
        <Stat label="Score" value={hud.score.toString()} />
        <Stat label="Length" value={hud.length.toString()} />
      </div>
      <div className="mt-5 flex flex-col gap-2">
        <Button size="lg" className="w-full" onClick={() => engine?.playLevel(hud.levelId)}>
          <RotateCcw className="size-4" />
          Restart
        </Button>
        <Button variant="secondary" className="w-full" onClick={() => engine?.openLevels()}>
          Levels
        </Button>
      </div>
    </Panel>
  );
}

function WinCard({ hud, engine }: { hud: HudSnapshot; engine: GameEngine | null }) {
  const last = hud.levelId >= hud.totalLevels;
  return (
    <Panel>
      <p className="text-xs font-medium tracking-[0.16em] text-good uppercase">Banner claimed</p>
      <h2 className="font-display mt-1 text-3xl font-semibold tracking-tight">
        {last ? "Every den is yours" : hud.levelName}
      </h2>
      <p className="mt-2 text-sm text-muted">
        {last ? "Five banners, one coil. Run it again cleaner." : "The next den is open."}
      </p>
      <div className="mt-4 grid grid-cols-2 gap-2">
        <Stat label="Score" value={hud.score.toString()} />
        <Stat label="Best" value={(hud.best || hud.score).toString()} />
      </div>
      <div className="mt-5 flex flex-col gap-2">
        {last ? null : (
          <Button size="lg" className="w-full" onClick={() => engine?.playLevel(hud.levelId + 1)}>
            Next level
          </Button>
        )}
        <Button
          variant={last ? "primary" : "secondary"}
          size="lg"
          className="w-full"
          onClick={() => engine?.playLevel(hud.levelId)}
        >
          Replay
        </Button>
        <Button variant="ghost" className="w-full" onClick={() => engine?.openLevels()}>
          Levels
        </Button>
      </div>
    </Panel>
  );
}

function TouchPad({ engine }: { engine: GameEngine | null }) {
  const held = useRef({ left: false, right: false, boost: false, brake: false });

  const apply = () => {
    if (!engine) return;
    const h = held.current;
    engine.setTouchSteer((h.left ? 1 : 0) + (h.right ? -1 : 0));
    engine.setTouchBoost(h.boost);
    engine.setTouchBrake(h.brake);
  };

  const bind = (key: keyof typeof held.current) => ({
    onPointerDown: (e: PointerEvent<HTMLButtonElement>) => {
      e.currentTarget.setPointerCapture(e.pointerId);
      held.current[key] = true;
      apply();
    },
    onPointerUp: () => {
      held.current[key] = false;
      apply();
    },
    onPointerCancel: () => {
      held.current[key] = false;
      apply();
    },
  });

  return (
    <div className="pointer-events-none absolute inset-x-0 bottom-0 z-10 flex items-end justify-between px-4 pb-[max(1rem,env(safe-area-inset-bottom))]">
      <div className="pointer-events-auto flex gap-2">
        <Pad label="Left" {...bind("left")} />
        <Pad label="Right" {...bind("right")} />
      </div>
      <div className="pointer-events-auto flex gap-2">
        <Pad label="Brake" {...bind("brake")} />
        <Pad label="Boost" {...bind("boost")} />
      </div>
    </div>
  );
}

function Pad({
  label,
  ...rest
}: { label: string } & HTMLAttributes<HTMLButtonElement>) {
  return (
    <button
      type="button"
      aria-label={label}
      className="h-14 min-w-14 rounded-xl border border-border bg-surface/85 px-4 text-xs font-medium text-fg backdrop-blur-sm"
      {...rest}
    >
      {label}
    </button>
  );
}
