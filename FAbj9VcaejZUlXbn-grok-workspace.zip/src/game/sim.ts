import { PLAYER_PALETTE } from "./palettes";
import { getLevel, isWall, tileCenter } from "./levels";
import type { Actions, Food, Flag, LevelDef, Particle, Pop, Snake, Vec } from "./types";

export type EventKind = "eat" | "burst" | "unlock" | "win" | "none";

export type StepResult = {
  event: EventKind;
  scoreDelta: number;
};

function wrapAngle(a: number) {
  while (a > Math.PI) a -= Math.PI * 2;
  while (a < -Math.PI) a += Math.PI * 2;
  return a;
}

function dist2(a: Vec, b: Vec) {
  const dx = a.x - b.x;
  const dy = a.y - b.y;
  return dx * dx + dy * dy;
}

function circleRect(cx: number, cy: number, r: number, rx: number, ry: number, rw: number, rh: number) {
  const nx = Math.max(rx, Math.min(cx, rx + rw));
  const ny = Math.max(ry, Math.min(cy, ry + rh));
  const dx = cx - nx;
  const dy = cy - ny;
  return dx * dx + dy * dy < r * r;
}

function makeSnake(
  id: number,
  isPlayer: boolean,
  x: number,
  y: number,
  yaw: number,
  length: number,
  palette: Snake["palette"],
  cruise: number,
): Snake {
  const fx = -Math.sin(yaw);
  const fy = -Math.cos(yaw);
  const points: Vec[] = [];
  const n = Math.max(6, Math.ceil(length / 5));
  for (let i = 0; i < n; i++) {
    points.push({ x: x - fx * i * 5, y: y - fy * i * 5 });
  }
  return {
    id,
    isPlayer,
    points,
    yaw,
    speed: cruise,
    length,
    alive: true,
    palette,
    pulse: 0,
    think: Math.random() * 0.2,
    desiredYaw: yaw,
    grace: 0.7,
    boost: 0,
    cruise,
  };
}

export class World {
  level: LevelDef;
  snakes: Snake[] = [];
  food: Food[] = [];
  particles: Particle[] = [];
  pops: Pop[] = [];
  flag: Flag = { x: 0, y: 0, unlocked: false };
  score = 0;
  eaten = 0;
  combo = 0;
  comboTimer = 0;
  time = 0;
  attract = false;
  trauma = 0;
  hitstop = 0;
  reducedMotion = false;
  private nextId = 1;

  constructor(levelId: number, attract = false) {
    this.level = getLevel(levelId);
    this.attract = attract;
    const spawn = tileCenter(this.level, this.level.player.x, this.level.player.y);
    this.snakes.push(
      makeSnake(
        this.nextId++,
        !attract,
        spawn.x,
        spawn.y,
        this.level.player.yaw,
        56,
        PLAYER_PALETTE,
        this.level.baseSpeed,
      ),
    );
    for (const e of this.level.enemies) {
      const p = tileCenter(this.level, e.x, e.y);
      this.snakes.push(makeSnake(this.nextId++, false, p.x, p.y, e.yaw, e.length, e.palette, e.speed));
    }
    const fp = tileCenter(this.level, this.level.flag.x, this.level.flag.y);
    this.flag = { x: fp.x, y: fp.y, unlocked: false };
    for (let i = 0; i < this.level.foodCount; i++) this.spawnFood();
  }

  player(): Snake | undefined {
    return this.snakes.find((s) => s.isPlayer);
  }

  worldSize() {
    return { w: this.level.cols * this.level.tile, h: this.level.rows * this.level.tile };
  }

  headRadius(snake: Snake) {
    return 9 + Math.min(4, snake.length / 90);
  }

  step(dt: number, actions: Actions): StepResult {
    let event: EventKind = "none";
    let scoreDelta = 0;
    if (this.hitstop > 0) {
      this.hitstop = Math.max(0, this.hitstop - dt);
      this.tickFx(dt * 0.4);
      return { event, scoreDelta };
    }

    this.time += dt;
    this.comboTimer = Math.max(0, this.comboTimer - dt);
    if (this.comboTimer <= 0) this.combo = 0;
    this.trauma = Math.max(0, this.trauma - dt * 1.6);

    for (const snake of this.snakes) {
      if (!snake.alive) continue;
      snake.grace = Math.max(0, snake.grace - dt);
      snake.pulse = Math.max(0, snake.pulse - dt * 3);
      if (snake.isPlayer && !this.attract) this.steerPlayer(snake, actions, dt);
      else this.steerAi(snake, dt);
      this.advance(snake, dt);
    }

    this.resolveEats((kind, d) => {
      if (kind === "eat") {
        event = "eat";
        scoreDelta += d;
      }
    });

    this.resolveCollisions(() => {
      event = "burst";
    });

    if (!this.flag.unlocked && this.eaten >= this.level.foodToUnlock) {
      this.flag.unlocked = true;
      event = "unlock";
      this.addTrauma(0.4);
    }

    const player = this.player();
    if (player?.alive && this.flag.unlocked && !this.attract) {
      const hr = this.headRadius(player);
      const head = player.points[0];
      if (head && dist2(head, this.flag) < (hr + 16) * (hr + 16)) {
        event = "win";
        const bonus = 200 * this.level.id + Math.round(player.length);
        this.score += bonus;
        scoreDelta += bonus;
        player.alive = true;
      }
    }

    this.maintainFood();
    this.tickFx(dt);
    return { event, scoreDelta };
  }

  private steerPlayer(snake: Snake, actions: Actions, dt: number) {
    snake.yaw += actions.steer * this.level.turnRate * dt;
    snake.yaw = wrapAngle(snake.yaw);
    const target = actions.brake
      ? this.level.brakeSpeed
      : actions.boost
        ? this.level.boostSpeed
        : this.level.baseSpeed;
    snake.speed += (target - snake.speed) * (1 - Math.exp(-14 * dt));
    snake.boost = actions.boost ? 1 : 0;
  }

  private steerAi(snake: Snake, dt: number) {
    snake.think -= dt;
    if (snake.think <= 0) {
      snake.think = 0.16 + Math.random() * 0.22;
      snake.desiredYaw = this.pickAiYaw(snake);
    }
    const err = wrapAngle(snake.desiredYaw - snake.yaw);
    const turn = Math.max(-1, Math.min(1, err / 0.35));
    snake.yaw += turn * this.level.turnRate * 0.92 * dt;
    snake.yaw = wrapAngle(snake.yaw);
    const threat = this.look(snake, 54, snake.yaw) < 0.4;
    const target = threat ? snake.cruise * 0.82 : snake.cruise;
    snake.speed += (target - snake.speed) * (1 - Math.exp(-10 * dt));
  }

  private pickAiYaw(snake: Snake): number {
    const head = snake.points[0];
    if (!head) return snake.yaw;
    const samples = [0, 0.7, -0.7, 1.2, -1.2, 1.8, -1.8];
    let best = snake.yaw;
    let bestScore = -Infinity;
    for (const off of samples) {
      const yaw = wrapAngle(snake.yaw + off);
      const safety = this.look(snake, 90, yaw);
      let score = safety * 4;
      const fx = -Math.sin(yaw);
      const fy = -Math.cos(yaw);
      let foodBonus = 0;
      for (const f of this.food) {
        const dx = f.x - head.x;
        const dy = f.y - head.y;
        const d = Math.hypot(dx, dy);
        if (d < 220 && dx * fx + dy * fy > 0) foodBonus = Math.max(foodBonus, (220 - d) / 220);
      }
      score += foodBonus * 2.2;
      if (off === 0) score += 0.15;
      if (score > bestScore) {
        bestScore = score;
        best = yaw;
      }
    }
    const hunger = this.food[0];
    if (hunger && Math.random() < 0.45) {
      const yawTo = Math.atan2(-(hunger.x - head.x), -(hunger.y - head.y));
      if (this.look(snake, 70, yawTo) > 0.35) best = yawTo;
    }
    return best;
  }

  private look(snake: Snake, dist: number, yaw: number) {
    const head = snake.points[0];
    if (!head) return 0;
    const fx = -Math.sin(yaw);
    const fy = -Math.cos(yaw);
    const steps = 5;
    for (let i = 1; i <= steps; i++) {
      const t = (i / steps) * dist;
      const p = { x: head.x + fx * t, y: head.y + fy * t };
      if (this.hitsWall(p.x, p.y, 8)) return (i - 1) / steps;
      if (this.hitsAnyBody(p, snake.id, 8)) return (i - 1) / steps;
    }
    return 1;
  }

  private advance(snake: Snake, dt: number) {
    const head = snake.points[0];
    if (!head) return;
    const dist = snake.speed * dt;
    const fx = -Math.sin(snake.yaw);
    const fy = -Math.cos(snake.yaw);
    const nx = head.x + fx * dist;
    const ny = head.y + fy * dist;
    snake.points.unshift({ x: nx, y: ny });
    let acc = 0;
    let keep = 1;
    for (let i = 1; i < snake.points.length; i++) {
      const a = snake.points[i - 1]!;
      const b = snake.points[i]!;
      acc += Math.hypot(a.x - b.x, a.y - b.y);
      keep = i + 1;
      if (acc >= snake.length) break;
    }
    if (keep < snake.points.length) snake.points.length = keep;
    if (snake.points.length > 280) snake.points.length = 280;
  }

  private resolveEats(onEat: (kind: EventKind, d: number) => void) {
    for (const snake of this.snakes) {
      if (!snake.alive) continue;
      const head = snake.points[0];
      if (!head) continue;
      const hr = this.headRadius(snake);
      for (let i = this.food.length - 1; i >= 0; i--) {
        const f = this.food[i]!;
        if (dist2(head, f) > (hr + f.r) * (hr + f.r)) continue;
        this.food.splice(i, 1);
        snake.length += 16 + f.value * 4;
        snake.pulse = 1;
        if (snake.isPlayer) {
          this.combo += 1;
          this.comboTimer = 0.9;
          const gained = (10 + f.value * 5) * Math.min(4, this.combo);
          this.score += gained;
          this.eaten += 1;
          this.pops.push({ x: head.x, y: head.y - 12, text: `+${gained}`, life: 0.7, max: 0.7 });
          this.emit(head.x, head.y, snake.palette.body, 10, 70);
          this.addTrauma(0.18);
          this.hitstop = this.reducedMotion ? 0 : 0.03;
          onEat("eat", gained);
        } else {
          this.emit(head.x, head.y, snake.palette.body, 6, 50);
        }
      }
    }
  }

  private resolveCollisions(onBurst: () => void) {
    const dying: Snake[] = [];
    for (const snake of this.snakes) {
      if (!snake.alive || snake.grace > 0) continue;
      const head = snake.points[0];
      if (!head) continue;
      const hr = this.headRadius(snake);
      if (this.hitsWall(head.x, head.y, hr * 0.82)) {
        dying.push(snake);
        continue;
      }
      if (this.hitsAnyBody(head, snake.id, hr * 0.78, snake)) dying.push(snake);
    }
    for (const snake of dying) {
      if (!snake.alive) continue;
      snake.alive = false;
      this.burstSnake(snake);
      if (snake.isPlayer) {
        this.addTrauma(0.75);
        this.hitstop = this.reducedMotion ? 0 : 0.08;
        onBurst();
      } else {
        this.addTrauma(0.32);
      }
    }
  }

  hitsWall(x: number, y: number, r: number) {
    const t = this.level.tile;
    const minC = Math.floor((x - r) / t);
    const maxC = Math.floor((x + r) / t);
    const minR = Math.floor((y - r) / t);
    const maxR = Math.floor((y + r) / t);
    for (let c = minC; c <= maxC; c++) {
      for (let row = minR; row <= maxR; row++) {
        if (!isWall(this.level, c, row)) continue;
        if (circleRect(x, y, r, c * t, row * t, t, t)) return true;
      }
    }
    return false;
  }

  private hitsAnyBody(p: Vec, selfId: number, r: number, self?: Snake) {
    for (const other of this.snakes) {
      if (!other.alive) continue;
      let start = 0;
      if (other.id === selfId) {
        start = this.skipOwn(other);
      }
      for (let i = start; i < other.points.length; i += 2) {
        const q = other.points[i]!;
        const br = other.id === selfId ? r * 0.7 : 7;
        if (dist2(p, q) < (r + br) * (r + br)) {
          if (self && other.id === selfId && i < 10) continue;
          return true;
        }
      }
    }
    return false;
  }

  private skipOwn(snake: Snake) {
    const head = snake.points[0];
    if (!head) return 12;
    let acc = 0;
    for (let i = 1; i < snake.points.length; i++) {
      const a = snake.points[i - 1]!;
      const b = snake.points[i]!;
      acc += Math.hypot(a.x - b.x, a.y - b.y);
      if (acc > 28) return i;
    }
    return snake.points.length;
  }

  private burstSnake(snake: Snake) {
    const pts = snake.points;
    for (let i = 0; i < pts.length; i += 3) {
      const p = pts[i]!;
      if (this.hitsWall(p.x, p.y, 6)) continue;
      this.food.push({
        x: p.x + (Math.random() - 0.5) * 6,
        y: p.y + (Math.random() - 0.5) * 6,
        r: 6 + Math.random() * 3,
        value: 2,
        seed: Math.random() * 10,
      });
    }
    const head = pts[0];
    if (head) this.emit(head.x, head.y, snake.palette.body, 28, 160);
    for (let i = 0; i < pts.length; i += 4) {
      const p = pts[i]!;
      this.emit(p.x, p.y, snake.palette.mid, 4, 80);
    }
  }

  private maintainFood() {
    let guard = 12;
    while (this.food.length < this.level.foodCount && guard-- > 0) this.spawnFood();
  }

  private spawnFood() {
    const t = this.level.tile;
    for (let k = 0; k < 30; k++) {
      const c = 1 + Math.floor(Math.random() * (this.level.cols - 2));
      const r = 1 + Math.floor(Math.random() * (this.level.rows - 2));
      if (isWall(this.level, c, r)) continue;
      const p = tileCenter(this.level, c, r);
      if (dist2(p, this.flag) < 40 * 40) continue;
      let near = false;
      for (const s of this.snakes) {
        if (!s.alive) continue;
        const h = s.points[0];
        if (h && dist2(h, p) < 50 * 50) near = true;
      }
      if (near) continue;
      this.food.push({
        x: p.x + (Math.random() - 0.5) * (t * 0.3),
        y: p.y + (Math.random() - 0.5) * (t * 0.3),
        r: 5.5,
        value: 1,
        seed: Math.random() * 10,
      });
      return;
    }
  }

  emit(x: number, y: number, color: string, n: number, speed: number) {
    if (this.reducedMotion) n = Math.min(n, 6);
    const cap = 220;
    for (let i = 0; i < n; i++) {
      if (this.particles.length >= cap) this.particles.shift();
      const a = Math.random() * Math.PI * 2;
      const s = speed * (0.3 + Math.random() * 0.7);
      this.particles.push({
        x,
        y,
        vx: Math.cos(a) * s,
        vy: Math.sin(a) * s,
        life: 0.35 + Math.random() * 0.35,
        max: 0.7,
        r: 1.6 + Math.random() * 2.4,
        color,
      });
    }
  }

  private tickFx(dt: number) {
    for (let i = this.particles.length - 1; i >= 0; i--) {
      const p = this.particles[i]!;
      p.life -= dt;
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      p.vx *= 0.92;
      p.vy *= 0.92;
      if (p.life <= 0) this.particles.splice(i, 1);
    }
    for (let i = this.pops.length - 1; i >= 0; i--) {
      const p = this.pops[i]!;
      p.life -= dt;
      p.y -= 28 * dt;
      if (p.life <= 0) this.pops.splice(i, 1);
    }
  }

  addTrauma(v: number) {
    if (this.reducedMotion) return;
    this.trauma = Math.min(1, this.trauma + v);
  }
}
