import { ENEMY_PALETTES } from "./palettes";
import type { LevelDef, SnakePalette } from "./types";

function grid(cols: number, rows: number, paint?: (set: (x: number, y: number, v?: number) => void) => void) {
  const walls = new Uint8Array(cols * rows);
  const set = (x: number, y: number, v = 1) => {
    if (x >= 0 && y >= 0 && x < cols && y < rows) walls[y * cols + x] = v;
  };
  for (let x = 0; x < cols; x++) {
    set(x, 0);
    set(x, rows - 1);
  }
  for (let y = 0; y < rows; y++) {
    set(0, y);
    set(cols - 1, y);
  }
  paint?.(set);
  return walls;
}

function enemy(
  x: number,
  y: number,
  yaw: number,
  length: number,
  palette: SnakePalette,
  speed: number,
) {
  return { x, y, yaw, length, palette, speed };
}

const T = 40;

export const LEVELS: LevelDef[] = [
  {
    id: 1,
    name: "Clearing",
    blurb: "A quiet field. Grow, then take the banner.",
    cols: 28,
    rows: 18,
    tile: T,
    walls: grid(28, 18, (set) => {
      set(8, 5);
      set(9, 5);
      set(8, 6);
      set(9, 6);
      set(19, 11);
      set(20, 11);
      set(19, 12);
      set(20, 12);
    }),
    player: { x: 5, y: 9, yaw: -Math.PI / 2 },
    enemies: [
      enemy(22, 4, Math.PI / 2, 70, ENEMY_PALETTES[0], 128),
      enemy(22, 14, Math.PI / 2, 62, ENEMY_PALETTES[1], 122),
    ],
    foodCount: 12,
    foodToUnlock: 8,
    flag: { x: 24, y: 9 },
    turnRate: 4.4,
    baseSpeed: 168,
    boostSpeed: 250,
    brakeSpeed: 92,
  },
  {
    id: 2,
    name: "Ruins",
    blurb: "Pillars break the line of sight. Watch the corners.",
    cols: 30,
    rows: 20,
    tile: T,
    walls: grid(30, 20, (set) => {
      for (const [x, y] of [
        [7, 6],
        [8, 6],
        [7, 7],
        [8, 7],
        [15, 4],
        [16, 4],
        [15, 5],
        [16, 5],
        [22, 8],
        [23, 8],
        [22, 9],
        [23, 9],
        [10, 13],
        [11, 13],
        [10, 14],
        [11, 14],
        [18, 15],
        [19, 15],
        [18, 16],
        [19, 16],
      ] as const) {
        set(x, y);
      }
    }),
    player: { x: 4, y: 10, yaw: -Math.PI / 2 },
    enemies: [
      enemy(25, 4, Math.PI / 2, 78, ENEMY_PALETTES[0], 136),
      enemy(25, 16, Math.PI / 2, 70, ENEMY_PALETTES[2], 130),
      enemy(14, 10, 0, 64, ENEMY_PALETTES[3], 124),
    ],
    foodCount: 14,
    foodToUnlock: 10,
    flag: { x: 26, y: 10 },
    turnRate: 4.5,
    baseSpeed: 176,
    boostSpeed: 262,
    brakeSpeed: 96,
  },
  {
    id: 3,
    name: "Hedge",
    blurb: "Lanes and gaps. Cut through, don't get boxed in.",
    cols: 32,
    rows: 20,
    tile: T,
    walls: grid(32, 20, (set) => {
      for (const y of [5, 10, 15]) {
        for (let x = 2; x < 30; x++) {
          if (x % 10 < 7) set(x, y);
        }
      }
    }),
    player: { x: 4, y: 2, yaw: -Math.PI / 2 },
    enemies: [
      enemy(28, 3, Math.PI / 2, 86, ENEMY_PALETTES[1], 142),
      enemy(28, 8, Math.PI / 2, 74, ENEMY_PALETTES[0], 138),
      enemy(4, 12, -Math.PI / 2, 70, ENEMY_PALETTES[4], 134),
      enemy(16, 17, Math.PI, 80, ENEMY_PALETTES[2], 140),
    ],
    foodCount: 16,
    foodToUnlock: 12,
    flag: { x: 28, y: 17 },
    turnRate: 4.6,
    baseSpeed: 182,
    boostSpeed: 272,
    brakeSpeed: 98,
  },
  {
    id: 4,
    name: "Split",
    blurb: "Two chambers, narrow doors. The banner waits on the far side.",
    cols: 32,
    rows: 22,
    tile: T,
    walls: grid(32, 22, (set) => {
      for (let y = 1; y < 21; y++) {
        if (y === 6 || y === 15) continue;
        set(16, y);
      }
      for (let x = 6; x <= 10; x++) {
        set(x, 8);
        set(x, 14);
      }
      for (let x = 21; x <= 25; x++) {
        set(x, 8);
        set(x, 14);
      }
    }),
    player: { x: 4, y: 11, yaw: -Math.PI / 2 },
    enemies: [
      enemy(12, 4, 0, 90, ENEMY_PALETTES[0], 148),
      enemy(12, 18, Math.PI, 82, ENEMY_PALETTES[3], 144),
      enemy(26, 4, Math.PI / 2, 88, ENEMY_PALETTES[1], 150),
      enemy(26, 18, Math.PI / 2, 76, ENEMY_PALETTES[5], 146),
    ],
    foodCount: 16,
    foodToUnlock: 12,
    flag: { x: 28, y: 11 },
    turnRate: 4.7,
    baseSpeed: 188,
    boostSpeed: 282,
    brakeSpeed: 100,
  },
  {
    id: 5,
    name: "Den",
    blurb: "Crowded, fast, unforgiving. Claim the last banner.",
    cols: 34,
    rows: 22,
    tile: T,
    walls: grid(34, 22, (set) => {
      for (let i = 4; i < 30; i += 6) {
        for (let k = 0; k < 3; k++) {
          set(i, 4 + k);
          set(i + 1, 4 + k);
          set(i, 15 + k);
          set(i + 1, 15 + k);
        }
      }
      for (let x = 10; x <= 23; x++) {
        if (x === 16 || x === 17) continue;
        set(x, 11);
      }
    }),
    player: { x: 4, y: 11, yaw: -Math.PI / 2 },
    enemies: [
      enemy(30, 3, Math.PI / 2, 96, ENEMY_PALETTES[0], 158),
      enemy(30, 11, Math.PI / 2, 88, ENEMY_PALETTES[2], 154),
      enemy(30, 19, Math.PI / 2, 92, ENEMY_PALETTES[1], 156),
      enemy(17, 3, 0, 80, ENEMY_PALETTES[4], 150),
      enemy(17, 19, Math.PI, 84, ENEMY_PALETTES[5], 152),
    ],
    foodCount: 18,
    foodToUnlock: 14,
    flag: { x: 31, y: 11 },
    turnRate: 4.9,
    baseSpeed: 198,
    boostSpeed: 298,
    brakeSpeed: 108,
  },
];

export const TOTAL_LEVELS = LEVELS.length;

export function getLevel(id: number): LevelDef {
  return LEVELS[Math.max(0, Math.min(LEVELS.length - 1, id - 1))]!;
}

export function tileCenter(level: LevelDef, col: number, row: number) {
  return { x: (col + 0.5) * level.tile, y: (row + 0.5) * level.tile };
}

export function isWall(level: LevelDef, col: number, row: number) {
  if (col < 0 || row < 0 || col >= level.cols || row >= level.rows) return true;
  return level.walls[row * level.cols + col] === 1;
}
