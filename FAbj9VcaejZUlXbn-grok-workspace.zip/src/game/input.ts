import type { Actions } from "./types";

const GAME_CODES = new Set([
  "KeyW",
  "KeyA",
  "KeyS",
  "KeyD",
  "ArrowUp",
  "ArrowDown",
  "ArrowLeft",
  "ArrowRight",
  "Space",
  "KeyP",
  "Escape",
  "Enter",
  "KeyM",
]);

function radialDeadzone(x: number, y: number, dz = 0.18) {
  const m = Math.hypot(x, y);
  if (m < dz) return { x: 0, y: 0 };
  const scale = (m - dz) / (1 - dz) / m;
  return { x: x * scale, y: y * scale };
}

export class Input {
  keys = new Set<string>();
  injected: string[] | null = null;
  touchSteer = 0;
  touchBoost = false;
  touchBrake = false;
  injectedSteer: number | null = null;
  private prevPause = false;
  private prevConfirm = false;
  pausePressed = false;
  confirmPressed = false;

  attach() {
    window.addEventListener("keydown", this.onKeyDown);
    window.addEventListener("keyup", this.onKeyUp);
    window.addEventListener("blur", this.onBlur);
    document.addEventListener("visibilitychange", this.onBlur);
  }

  detach() {
    window.removeEventListener("keydown", this.onKeyDown);
    window.removeEventListener("keyup", this.onKeyUp);
    window.removeEventListener("blur", this.onBlur);
    document.removeEventListener("visibilitychange", this.onBlur);
    this.keys.clear();
  }

  setKeys(codes: string[]) {
    this.injected = codes.length ? [...codes] : null;
  }

  private onKeyDown = (e: KeyboardEvent) => {
    if (GAME_CODES.has(e.code)) e.preventDefault();
    this.keys.add(e.code);
  };

  private onKeyUp = (e: KeyboardEvent) => {
    this.keys.delete(e.code);
  };

  private onBlur = () => {
    this.keys.clear();
    this.touchSteer = 0;
    this.touchBoost = false;
    this.touchBrake = false;
  };

  sample(): Actions {
    const held = this.injected ? new Set(this.injected) : this.keys;
    let steer = this.injectedSteer ?? this.touchSteer;
    if (this.injectedSteer == null) {
      if (held.has("KeyA") || held.has("ArrowLeft")) steer += 1;
      if (held.has("KeyD") || held.has("ArrowRight")) steer -= 1;
    }

    const pads = typeof navigator !== "undefined" ? navigator.getGamepads?.() : null;
    if (pads) {
      for (const pad of pads) {
        if (!pad || pad.mapping !== "standard") continue;
        const stick = radialDeadzone(pad.axes[0] ?? 0, pad.axes[1] ?? 0);
        // Stick left should turn left: +steer
        steer += -stick.x;
        if (pad.buttons[0]?.pressed || (pad.buttons[7]?.value ?? 0) > 0.4) this.touchBoost = true;
        if (pad.buttons[1]?.pressed || (pad.buttons[6]?.value ?? 0) > 0.4) this.touchBrake = true;
        if (pad.buttons[12]?.pressed) this.touchBoost = true;
        if (pad.buttons[13]?.pressed) this.touchBrake = true;
        if (pad.buttons[14]?.pressed) steer += 1;
        if (pad.buttons[15]?.pressed) steer -= 1;
      }
    }

    steer = Math.max(-1, Math.min(1, steer));

    const boost =
      held.has("KeyW") || held.has("ArrowUp") || held.has("Space") || this.touchBoost;
    const brake = held.has("KeyS") || held.has("ArrowDown") || this.touchBrake;
    const pause = held.has("KeyP") || held.has("Escape");
    const confirm = held.has("Enter");

    this.pausePressed = pause && !this.prevPause;
    this.confirmPressed = confirm && !this.prevConfirm;
    this.prevPause = pause;
    this.prevConfirm = confirm;

    return { steer, boost, brake, pause, confirm };
  }
}
