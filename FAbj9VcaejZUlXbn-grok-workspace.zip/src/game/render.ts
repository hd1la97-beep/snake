import { isWall } from "./levels";
import type { World } from "./sim";
import type { Flag, Food, LevelDef, Snake, Vec } from "./types";

type Cam = { x: number; y: number; scale: number; shakeX: number; shakeY: number; shakeR: number };

export function computeCam(
  world: World,
  viewW: number,
  viewH: number,
  follow: Vec | null,
  dt: number,
  cam: Cam,
) {
  const { w, h } = world.worldSize();
  const targetScale = Math.min(viewW / 980, viewH / 720);
  const scale = Math.max(0.38, Math.min(1.15, targetScale));
  cam.scale += (scale - cam.scale) * (1 - Math.exp(-8 * dt));
  const target = follow ?? { x: w / 2, y: h / 2 };
  cam.x += (target.x - cam.x) * (1 - Math.exp(-6 * dt));
  cam.y += (target.y - cam.y) * (1 - Math.exp(-6 * dt));
  const shake = world.trauma * world.trauma;
  cam.shakeX = (Math.random() * 2 - 1) * 14 * shake;
  cam.shakeY = (Math.random() * 2 - 1) * 14 * shake;
  cam.shakeR = (Math.random() * 2 - 1) * 0.03 * shake;
  return cam;
}

export function createCam(): Cam {
  return { x: 0, y: 0, scale: 0.7, shakeX: 0, shakeY: 0, shakeR: 0 };
}

export function drawWorld(
  ctx: CanvasRenderingContext2D,
  world: World,
  viewW: number,
  viewH: number,
  cam: Cam,
  dpr: number,
) {
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.clearRect(0, 0, viewW, viewH);
  ctx.fillStyle = "#0c100e";
  ctx.fillRect(0, 0, viewW, viewH);

  ctx.save();
  ctx.translate(viewW / 2 + cam.shakeX, viewH / 2 + cam.shakeY);
  ctx.rotate(cam.shakeR);
  ctx.scale(cam.scale, cam.scale);
  ctx.translate(-cam.x, -cam.y);

  const { w, h } = world.worldSize();
  drawFloor(ctx, world.level, w, h);
  drawWalls(ctx, world.level);
  drawFlag(ctx, world.flag, world.time, world.eaten, world.level.foodToUnlock);
  for (const f of world.food) drawFood(ctx, f, world.time);
  const snakes = world.snakes.filter((s) => s.alive);
  snakes.sort((a, b) => Number(a.isPlayer) - Number(b.isPlayer));
  for (const s of snakes) drawSnake(ctx, s, world);
  drawFx(ctx, world);

  ctx.restore();

  const g = ctx.createRadialGradient(
    viewW / 2,
    viewH / 2,
    viewW * 0.2,
    viewW / 2,
    viewH / 2,
    viewW * 0.75,
  );
  g.addColorStop(0, "rgba(12,16,14,0)");
  g.addColorStop(1, "rgba(12,16,14,0.42)");
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, viewW, viewH);
}

function drawFloor(ctx: CanvasRenderingContext2D, level: LevelDef, w: number, h: number) {
  ctx.fillStyle = "#121814";
  ctx.fillRect(0, 0, w, h);
  ctx.strokeStyle = "rgba(232,238,233,0.035)";
  ctx.lineWidth = 1;
  const t = level.tile;
  ctx.beginPath();
  for (let x = 0; x <= w; x += t) {
    ctx.moveTo(x, 0);
    ctx.lineTo(x, h);
  }
  for (let y = 0; y <= h; y += t) {
    ctx.moveTo(0, y);
    ctx.lineTo(w, y);
  }
  ctx.stroke();
}

function drawWalls(ctx: CanvasRenderingContext2D, level: LevelDef) {
  const t = level.tile;
  for (let r = 0; r < level.rows; r++) {
    for (let c = 0; c < level.cols; c++) {
      if (!isWall(level, c, r)) continue;
      const x = c * t;
      const y = r * t;
      ctx.fillStyle = "#1c2621";
      roundRect(ctx, x + 1, y + 1, t - 2, t - 2, 6);
      ctx.fill();
      ctx.fillStyle = "rgba(232,238,233,0.05)";
      roundRect(ctx, x + 3, y + 2, t - 6, t * 0.28, 4);
      ctx.fill();
    }
  }
}

function drawFood(ctx: CanvasRenderingContext2D, f: Food, time: number) {
  const pulse = 1 + Math.sin(time * 5.5 + f.seed) * 0.12;
  const r = f.r * pulse;
  const g = ctx.createRadialGradient(f.x, f.y, 0, f.x, f.y, r * 3);
  g.addColorStop(0, "rgba(232,238,233,0.28)");
  g.addColorStop(1, "rgba(232,238,233,0)");
  ctx.fillStyle = g;
  ctx.beginPath();
  ctx.arc(f.x, f.y, r * 3, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = f.value > 1 ? "#d5dbd6" : "#b8c4ba";
  ctx.beginPath();
  ctx.arc(f.x, f.y, r, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = "rgba(255,255,255,0.45)";
  ctx.beginPath();
  ctx.arc(f.x - r * 0.25, f.y - r * 0.25, r * 0.32, 0, Math.PI * 2);
  ctx.fill();
}

function drawFlag(ctx: CanvasRenderingContext2D, flag: Flag, time: number, eaten: number, need: number) {
  const unlocked = flag.unlocked;
  ctx.save();
  ctx.translate(flag.x, flag.y);
  ctx.strokeStyle = unlocked ? "#d5dbd6" : "#5c665f";
  ctx.lineWidth = 3;
  ctx.lineCap = "round";
  ctx.beginPath();
  ctx.moveTo(0, 16);
  ctx.lineTo(0, -22);
  ctx.stroke();
  ctx.fillStyle = unlocked ? "#1c2621" : "#161c18";
  ctx.beginPath();
  ctx.arc(0, 16, 4, 0, Math.PI * 2);
  ctx.fill();

  const wave = Math.sin(time * 4) * (unlocked ? 4 : 1.5);
  ctx.beginPath();
  ctx.moveTo(1, -21);
  ctx.lineTo(26 + wave, -14);
  ctx.lineTo(1, -6);
  ctx.closePath();
  ctx.fillStyle = unlocked ? "#e8eee9" : "#3a4440";
  ctx.fill();
  if (unlocked) {
    ctx.fillStyle = "#5ecf9a";
    ctx.beginPath();
    ctx.moveTo(6, -18);
    ctx.lineTo(12, -15.5);
    ctx.lineTo(6, -13);
    ctx.closePath();
    ctx.fill();
  } else {
    ctx.fillStyle = "#8b958d";
    ctx.font = "600 9px Figtree, sans-serif";
    ctx.textAlign = "center";
    ctx.fillText(`${Math.min(eaten, need)}/${need}`, 0, 28);
  }
  if (unlocked) {
    const glow = ctx.createRadialGradient(0, -12, 2, 0, -12, 36);
    glow.addColorStop(0, "rgba(94,207,154,0.16)");
    glow.addColorStop(1, "rgba(94,207,154,0)");
    ctx.fillStyle = glow;
    ctx.beginPath();
    ctx.arc(0, -8, 36, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.restore();
}

function drawSnake(ctx: CanvasRenderingContext2D, snake: Snake, world: World) {
  const pts = snake.points;
  if (pts.length < 2) return;
  const headR = world.headRadius(snake) * (1 + snake.pulse * 0.12);
  for (let i = pts.length - 1; i >= 0; i--) {
    const t = i / Math.max(1, pts.length - 1);
    const p = pts[i]!;
    const r = lerp(3.2, headR, Math.pow(t, 0.55));
    ctx.fillStyle = t > 0.72 ? snake.palette.body : t > 0.35 ? snake.palette.mid : snake.palette.tail;
    ctx.beginPath();
    ctx.arc(p.x, p.y, r, 0, Math.PI * 2);
    ctx.fill();
  }
  const head = pts[0]!;
  const fx = -Math.sin(snake.yaw);
  const fy = -Math.cos(snake.yaw);
  const lx = fy;
  const ly = -fx;
  ctx.fillStyle = "rgba(232,238,233,0.18)";
  ctx.beginPath();
  ctx.arc(head.x + fx * headR * 0.15, head.y + fy * headR * 0.15, headR * 0.55, 0, Math.PI * 2);
  ctx.fill();

  const eyeR = Math.max(2.1, headR * 0.28);
  const pupil = eyeR * 0.46;
  const e1 = {
    x: head.x + fx * headR * 0.32 + lx * headR * 0.38,
    y: head.y + fy * headR * 0.32 + ly * headR * 0.38,
  };
  const e2 = {
    x: head.x + fx * headR * 0.32 - lx * headR * 0.38,
    y: head.y + fy * headR * 0.32 - ly * headR * 0.38,
  };
  for (const e of [e1, e2]) {
    ctx.fillStyle = "#e8eee9";
    ctx.beginPath();
    ctx.arc(e.x, e.y, eyeR, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = snake.palette.eye;
    ctx.beginPath();
    ctx.arc(e.x + fx * pupil * 0.7, e.y + fy * pupil * 0.7, pupil, 0, Math.PI * 2);
    ctx.fill();
  }
}

function drawFx(ctx: CanvasRenderingContext2D, world: World) {
  for (const p of world.particles) {
    const a = Math.max(0, p.life / p.max);
    ctx.globalAlpha = a;
    ctx.fillStyle = p.color;
    ctx.beginPath();
    ctx.arc(p.x, p.y, p.r * a, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.globalAlpha = 1;
  ctx.font = "600 12px Figtree, sans-serif";
  ctx.textAlign = "center";
  for (const p of world.pops) {
    ctx.globalAlpha = Math.max(0, p.life / p.max);
    ctx.fillStyle = "#e8eee9";
    ctx.fillText(p.text, p.x, p.y);
  }
  ctx.globalAlpha = 1;
}

function lerp(a: number, b: number, t: number) {
  return a + (b - a) * t;
}

function roundRect(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  r: number,
) {
  const rr = Math.min(r, w / 2, h / 2);
  ctx.beginPath();
  ctx.moveTo(x + rr, y);
  ctx.arcTo(x + w, y, x + w, y + h, rr);
  ctx.arcTo(x + w, y + h, x, y + h, rr);
  ctx.arcTo(x, y + h, x, y, rr);
  ctx.arcTo(x, y, x + w, y, rr);
  ctx.closePath();
}
