export class AudioBus {
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  muted = false;

  unlock() {
    if (!this.ctx) {
      const Ctor = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.ctx = new Ctor({ latencyHint: "interactive" });
      this.master = this.ctx.createGain();
      this.master.gain.value = this.muted ? 0 : 0.7;
      this.master.connect(this.ctx.destination);
    }
    if (this.ctx.state === "suspended") void this.ctx.resume();
  }

  resume() {
    if (this.ctx?.state === "suspended") void this.ctx.resume();
  }

  setMuted(muted: boolean) {
    this.muted = muted;
    if (this.master && this.ctx) {
      this.master.gain.setTargetAtTime(muted ? 0 : 0.7, this.ctx.currentTime, 0.02);
    }
  }

  private tone(freq: number, dur: number, type: OscillatorType, gain = 0.12, slide = 0) {
    if (!this.ctx || !this.master || this.muted) return;
    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const g = this.ctx.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(freq, t);
    if (slide) osc.frequency.exponentialRampToValueAtTime(Math.max(40, freq + slide), t + dur);
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(gain, t + 0.012);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    osc.connect(g);
    g.connect(this.master);
    osc.start(t);
    osc.stop(t + dur + 0.02);
    osc.onended = () => {
      osc.disconnect();
      g.disconnect();
    };
  }

  eat() {
    const jitter = 1 + (Math.random() * 0.16 - 0.08);
    this.tone(620 * jitter, 0.07, "sine", 0.1);
    this.tone(930 * jitter, 0.05, "triangle", 0.05);
  }

  burst() {
    this.tone(180, 0.28, "sawtooth", 0.1, -120);
    this.tone(70, 0.34, "square", 0.06, -30);
  }

  unlockFlag() {
    this.tone(440, 0.12, "sine", 0.09);
    this.tone(660, 0.16, "triangle", 0.07);
  }

  win() {
    this.tone(523, 0.14, "sine", 0.1);
    this.tone(659, 0.16, "sine", 0.09);
    this.tone(784, 0.22, "triangle", 0.08);
  }

  click() {
    this.tone(480, 0.04, "square", 0.04);
  }
}
