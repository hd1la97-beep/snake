export type Vec = { x: number; y: number };

export type SnakeId = number;

export type SnakePalette = {
  body: string;
  mid: string;
  tail: string;
  eye: string;
};

export type Snake = {
  id: SnakeId;
  isPlayer: boolean;
  points: Vec[];
  yaw: number;
  speed: number;
  length: number;
  alive: boolean;
  palette: SnakePalette;
  pulse: number;
  think: number;
  desiredYaw: number;
  grace: number;
  boost: number;
  cruise: number;
};

export type Food = {
  x: number;
  y: number;
  r: number;
  value: number;
  seed: number;
};

export type Particle = {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  max: number;
  r: number;
  color: string;
};

export type Pop = {
  x: number;
  y: number;
  text: string;
  life: number;
  max: number;
};

export type Flag = {
  x: number;
  y: number;
  unlocked: boolean;
};

export type LevelDef = {
  id: number;
  name: string;
  blurb: string;
  cols: number;
  rows: number;
  tile: number;
  walls: Uint8Array;
  player: { x: number; y: number; yaw: number };
  enemies: { x: number; y: number; yaw: number; length: number; palette: SnakePalette; speed: number }[];
  foodCount: number;
  foodToUnlock: number;
  flag: { x: number; y: number };
  turnRate: number;
  baseSpeed: number;
  boostSpeed: number;
  brakeSpeed: number;
};

export type Phase = "title" | "levels" | "play" | "pause" | "dead" | "win";

export type HudSnapshot = {
  phase: Phase;
  levelId: number;
  levelName: string;
  score: number;
  length: number;
  eaten: number;
  need: number;
  flagReady: boolean;
  unlocked: number;
  best: number;
  muted: boolean;
  totalLevels: number;
};

export type Actions = {
  steer: number;
  boost: boolean;
  brake: boolean;
  pause: boolean;
  confirm: boolean;
};

export type ControlsProbe = {
  getYaw: () => number;
  getSpeed: () => number;
  setSteer?: (v: number) => void;
  setKeys?: (codes: string[]) => void;
};

declare global {
  interface Window {
    __controlsTest?: ControlsProbe;
  }
}
