import { AudioBus } from "./audio";
import { Input } from "./input";
import { TOTAL_LEVELS } from "./levels";
import { computeCam, createCam, drawWorld } from "./render";
import { loadSave, writeSave, type SaveData } from "./save";
import { World } from "./sim";
import type { HudSnapshot, Phase } from "./types";

export type HudListener = (hud: HudSnapshot) => void;

export class GameEngine {
  private canvas: HTMLCanvasElement;
  private ctx: CanvasRenderingContext2D;
  private input = new Input();
  private audio = new AudioBus();
  world: World;
  private cam = createCam();
  private raf = 0;
  private acc = 0;
  private last = 0;
  private running = false;
  private dpr = 1;
  private viewW = 1;
  private viewH = 1;
  private save: SaveData;
  private phase: Phase = "title";
  private levelId = 1;
  private onHud: HudListener;
  private reducedMotion = false;
  private resizeObs: ResizeObserver | null = null;

  constructor(canvas: HTMLCanvasElement, onHud: HudListener) {
    this.canvas = canvas;
    const ctx = canvas.getContext("2d");
    if (!ctx) throw new Error("Canvas 2D unavailable");
    this.ctx = ctx;
    this.onHud = onHud;
    this.save = loadSave();
    this.audio.setMuted(this.save.muted);
    this.reducedMotion = window.matchMedia?.("(prefers-reduced-motion: reduce)").matches ?? false;
    this.world = new World(1, true);
    this.world.reducedMotion = this.reducedMotion;
    this.input.attach();
    this.bindProbe();
    this.watchSize();
    this.emitHud();
  }

  start() {
    if (this.running) return;
    this.running = true;
    this.last = performance.now();
    this.raf = requestAnimationFrame(this.frame);
  }

  destroy() {
    this.running = false;
    cancelAnimationFrame(this.raf);
    this.input.detach();
    this.resizeObs?.disconnect();
    if (window.__controlsTest) delete window.__controlsTest;
  }

  unlockAudio() {
    this.audio.unlock();
  }

  playLevel(id: number) {
    this.audio.unlock();
    this.audio.click();
    this.levelId = id;
    this.world = new World(id, false);
    this.world.reducedMotion = this.reducedMotion;
    const p = this.world.player()?.points[0];
    if (p) {
      this.cam.x = p.x;
      this.cam.y = p.y;
    }
    this.phase = "play";
    this.emitHud();
  }

  openLevels() {
    this.audio.unlock();
    this.audio.click();
    this.phase = "levels";
    this.ensureAttract();
    this.emitHud();
  }

  backToTitle() {
    this.audio.click();
    this.phase = "title";
    this.ensureAttract();
    this.emitHud();
  }

  togglePause() {
    if (this.phase === "play") {
      this.phase = "pause";
      this.emitHud();
    } else if (this.phase === "pause") {
      this.phase = "play";
      this.emitHud();
    }
  }

  toggleMute() {
    this.save.muted = !this.save.muted;
    this.audio.setMuted(this.save.muted);
    writeSave(this.save);
    this.emitHud();
  }

  setTouchSteer(v: number) {
    this.input.touchSteer = v;
  }

  setTouchBoost(v: boolean) {
    this.input.touchBoost = v;
  }

  setTouchBrake(v: boolean) {
    this.input.touchBrake = v;
  }

  private ensureAttract() {
    if (!this.world.attract) {
      this.world = new World(1, true);
      this.world.reducedMotion = this.reducedMotion;
    }
  }

  private frame = (now: number) => {
    if (!this.running) return;
    const dt = Math.min(0.1, (now - this.last) / 1000);
    this.last = now;
    this.acc += dt;
    const step = 1 / 60;
    const actions = this.input.sample();

    if (this.input.pausePressed && (this.phase === "play" || this.phase === "pause")) {
      this.togglePause();
    }

    const simulating = this.phase === "play" || this.phase === "title" || this.phase === "levels";
    while (this.acc >= step) {
      if (simulating) {
        const playerActions =
          this.phase === "play" ? actions : { steer: 0, boost: false, brake: false, pause: false, confirm: false };
        const result = this.world.step(step, playerActions);
        if (this.phase === "play") this.handleEvent(result.event);
      }
      this.acc -= step;
    }

    const player = this.world.player();
    const follow =
      this.phase === "play" && player?.points[0]
        ? player.points[0]
        : this.world.snakes.find((s) => s.alive)?.points[0] ?? null;
    computeCam(this.world, this.viewW, this.viewH, follow, dt, this.cam);
    drawWorld(this.ctx, this.world, this.viewW, this.viewH, this.cam, this.dpr);

    this.raf = requestAnimationFrame(this.frame);
  };

  private handleEvent(event: string) {
    if (event === "eat") this.audio.eat();
    if (event === "burst") {
      this.audio.burst();
      this.phase = "dead";
      this.emitHud();
    }
    if (event === "unlock") this.audio.unlockFlag();
    if (event === "win") {
      this.audio.win();
      const idx = this.levelId - 1;
      this.save.best[idx] = Math.max(this.save.best[idx] ?? 0, this.world.score);
      this.save.unlocked = Math.max(this.save.unlocked, Math.min(TOTAL_LEVELS, this.levelId + 1));
      writeSave(this.save);
      this.phase = "win";
      this.emitHud();
    }
    if (event === "eat" || event === "unlock") this.emitHud();
  }

  private watchSize() {
    const apply = () => {
      const parent = this.canvas.parentElement ?? this.canvas;
      const rect = parent.getBoundingClientRect();
      this.viewW = Math.max(1, rect.width);
      this.viewH = Math.max(1, rect.height);
      this.dpr = Math.min(2, window.devicePixelRatio || 1);
      this.canvas.width = Math.floor(this.viewW * this.dpr);
      this.canvas.height = Math.floor(this.viewH * this.dpr);
      this.canvas.style.width = `${this.viewW}px`;
      this.canvas.style.height = `${this.viewH}px`;
    };
    apply();
    this.resizeObs = new ResizeObserver(apply);
    this.resizeObs.observe(this.canvas.parentElement ?? this.canvas);
  }

  emitHud() {
    const player = this.world.player();
    const length = player ? Math.max(3, Math.round(player.length / 14)) : 3;
    this.onHud({
      phase: this.phase,
      levelId: this.levelId,
      levelName: this.world.attract ? "Coilbound" : this.world.level.name,
      score: this.world.score,
      length,
      eaten: this.world.eaten,
      need: this.world.level.foodToUnlock,
      flagReady: this.world.flag.unlocked,
      unlocked: this.save.unlocked,
      best: this.save.best[this.levelId - 1] ?? 0,
      muted: this.save.muted,
      totalLevels: TOTAL_LEVELS,
    });
  }

  getSave() {
    return this.save;
  }

  private bindProbe() {
    window.__controlsTest = {
      getYaw: () => this.world.player()?.yaw ?? 0,
      getSpeed: () => this.world.player()?.speed ?? 0,
      setKeys: (codes) => {
        if (this.phase !== "play") {
          this.playLevel(this.levelId || 1);
        }
        this.input.setKeys(codes);
      },
      setSteer: (v) => {
        this.input.injectedSteer = v;
      },
    };
  }
}
