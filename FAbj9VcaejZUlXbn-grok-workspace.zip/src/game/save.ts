const KEY = "coilbound-v1";

export type SaveData = {
  version: 1;
  unlocked: number;
  best: number[];
  muted: boolean;
};

const FALLBACK: SaveData = { version: 1, unlocked: 1, best: [0, 0, 0, 0, 0], muted: false };

export function loadSave(): SaveData {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return { ...FALLBACK, best: [...FALLBACK.best] };
    const parsed = JSON.parse(raw) as Partial<SaveData>;
    if (parsed.version !== 1) return { ...FALLBACK, best: [...FALLBACK.best] };
    return {
      version: 1,
      unlocked: Math.max(1, Math.min(5, parsed.unlocked ?? 1)),
      best: Array.from({ length: 5 }, (_, i) => Math.max(0, parsed.best?.[i] ?? 0)),
      muted: Boolean(parsed.muted),
    };
  } catch {
    return { ...FALLBACK, best: [...FALLBACK.best] };
  }
}

export function writeSave(data: SaveData) {
  try {
    localStorage.setItem(KEY, JSON.stringify(data));
  } catch {
    /* private mode */
  }
}
