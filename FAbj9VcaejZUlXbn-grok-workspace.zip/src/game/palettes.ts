import type { SnakePalette } from "./types";

export const PLAYER_PALETTE: SnakePalette = {
  body: "#6fe0b0",
  mid: "#3aa97c",
  tail: "#1d6a4c",
  eye: "#0c100e",
};

export const ENEMY_PALETTES: SnakePalette[] = [
  { body: "#e07a68", mid: "#c45c4a", tail: "#7a3328", eye: "#1a0c0a" },
  { body: "#7ea4bc", mid: "#5b8299", tail: "#2e4a5a", eye: "#0c1216" },
  { body: "#c48aa0", mid: "#a06880", tail: "#5a3848", eye: "#160c10" },
  { body: "#8aaa6e", mid: "#6a8a52", tail: "#3a4e2c", eye: "#0c140a" },
  { body: "#c4a070", mid: "#a08050", tail: "#5a4830", eye: "#14100a" },
  { body: "#6aa8a4", mid: "#4a8480", tail: "#285250", eye: "#0a1212" },
];
